package com.example.walksensor.Model;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

/**
 * 判断需要在日历上显示的天数
 */
public class daysOfMonthes {
    public static int getDays(int month) {
        Calendar cal = Calendar.getInstance(TimeZone.getDefault());

        int currentYear = cal.get(Calendar.YEAR);//当前年份

        int days = 0;//记录全月天数,初始值为题头星期栏。

        if (isBigMonth(month)) {
            if (month == 2) {
                if (isLeapYear(currentYear)) days = 29;

                else
                    days = 28;
            } else
                days = 31;
        } else
            days = 30;

        return days;
    }

    public static boolean isLeapYear(int year) {
        return year % 400 == 0 || (year % 4 == 0 && year % 100 != 0) ? true : false;
    }

    public static boolean isBigMonth(int month) {
        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
            return true;
        else
            return false;
    }

    public static int theFirstDayOfMonth(int year, int month) {
        Calendar calendar = Calendar.getInstance();

        calendar.set(year, month - 1, 1);//传入的月份需要减去1才是需要的月份

        SimpleDateFormat dateFormat = new SimpleDateFormat("E");

        switch (dateFormat.format(calendar.getTime())) {
            case "周一" :
                return 0;
            case "周二" :
                return 1;
            case "周三" :
                return 2;
            case "周四" :
                return 3;
            case "周五" :
                return 4;
            case "周六" :
                return 5;
            default:
                return 6;
        }
    }
}
