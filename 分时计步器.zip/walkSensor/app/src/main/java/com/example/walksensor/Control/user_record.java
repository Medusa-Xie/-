package com.example.walksensor.Control;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.walksensor.R;
import com.example.walksensor.DataBase.*;

public class user_record extends AppCompatActivity {
    private TextView[] dates;
    private TextView[] steps;

    private final int GRID_ROW = 6;

    private databaseHelper helper = MainActivity.helper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_record);

        dates = new TextView[GRID_ROW];
        steps = new TextView[GRID_ROW];

        Button more = (Button) findViewById(R.id.more);
        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(user_record.this, know_more.class);

                startActivity(intent);
            }
        });

        initDates();
        initSteps();

        db = helper.getWritableDatabase();

        show_userData();
    }

    private void initDates() {
        dates[0] = (TextView) findViewById(R.id.date_1);
        dates[1] = (TextView) findViewById(R.id.date_2);
        dates[2] = (TextView) findViewById(R.id.date_3);
        dates[3] = (TextView) findViewById(R.id.date_4);
        dates[4] = (TextView) findViewById(R.id.date_5);
        dates[5] = (TextView) findViewById(R.id.date_6);
    }

    private void initSteps() {
        steps[0] = (TextView) findViewById(R.id.steps_1);
        steps[1] = (TextView) findViewById(R.id.steps_2);
        steps[2] = (TextView) findViewById(R.id.steps_3);
        steps[3] = (TextView) findViewById(R.id.steps_4);
        steps[4] = (TextView) findViewById(R.id.steps_5);
        steps[5] = (TextView) findViewById(R.id.steps_6);
    }

    private void show_userData() {
        Cursor cursor = db.query("data", null, null, null,
                null, null, "date desc");

        if (cursor != null) {
            int i = 0;

            while (cursor.moveToNext()) {
                String date = cursor.getString(cursor.getColumnIndex("date"));
                String step = cursor.getString(cursor.getColumnIndex("totalSteps"));

                if (step == null) step = "未记录";

                dates[i].setText(date);
                steps[i++].setText(step);
            }

            for (int j = i; j < GRID_ROW; j++) {
                dates[j].setText("--");
                steps[j].setText("--");
            }

            cursor.close();
        }
    }
}
