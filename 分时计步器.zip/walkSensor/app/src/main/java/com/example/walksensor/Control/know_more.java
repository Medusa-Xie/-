package com.example.walksensor.Control;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import com.example.walksensor.R;
import com.example.walksensor.Model.*;
import com.example.walksensor.DataBase.*;
import com.example.walksensor.Services.*;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Date;

public class know_more extends AppCompatActivity {
    private static final String TAG = "know_more";

    SimpleDateFormat dateFormat;

    private GridLayout calendar;
    private GridLayout table;
    private TextView date_title;
    private TextView table_date;
    private TextView[] textViews;
    private static TextView update_counter;

    private int CALENDAR_ROW = 0;//calendar行数
    private int CALENDAR_COL = 0;//calendar列数

    private int TABLE_COL = 2;//table列数
    private int TABLE_ROW = 0;//table行数

    private int CALENDAR_COL_NUM = 7;

    private String NOW_DATE = "";//当前日期
    private int YEAR = 0;//当前年
    private int MONTH = 0;//当前月
    private int DAYS = 0;//这个月一共有多少天

    private String QUERY_DATE = "";//点击对应日期后，组合而成的日期字符串yyyy-mm-dd

    private GridLayout.LayoutParams params;

    private databaseHelper helper = MainActivity.helper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_know_more);

        db = helper.getWritableDatabase();

        textViews = new TextView[9];// 9个时段的步数记录显示控件
        for (int i = 0; i < 9; i++) textViews[i] = new TextView(this);

        calendar = findViewById(R.id.calender);
        table = findViewById(R.id.table);

        dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        NOW_DATE = dateFormat.format(new Date());
        QUERY_DATE = NOW_DATE.substring(0, 10);
        MONTH = Integer.parseInt(NOW_DATE.substring(5, 7));
        YEAR = Integer.parseInt(NOW_DATE.substring(0, 4));

        DAYS = daysOfMonthes.getDays(MONTH);

        Log.i(TAG, "onCreate: " + "当前日期：" + NOW_DATE);
        Log.i(TAG, "onCreate: " + DAYS + "天");

        show_head();
        show_Calendar();
        query_stepData();
        show_table();
    }

    private void setDate_title(int year, int month) {
        date_title.setText(year + "-" + month);
    }

    private void show_Calendar() {
        CALENDAR_COL = daysOfMonthes.theFirstDayOfMonth(YEAR, MONTH);
        CALENDAR_ROW = daysOfMonthes.theFirstDayOfMonth(YEAR, MONTH);

        for (int i = 0; i < DAYS; i++) {
            params = new GridLayout.LayoutParams();

            final Button bt = new Button(this);

            bt.setText(i + 1 + "");
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    QUERY_DATE = date_title.getText() + "-" + bt.getText();

                    setTable_date(QUERY_DATE);

                    query_stepData();
                }
            });

            params.width = 155;
            params.height = 155;

            params.columnSpec = GridLayout.spec(CALENDAR_COL++ % CALENDAR_COL_NUM, 1);
            params.rowSpec = GridLayout.spec(2 + CALENDAR_ROW++ / CALENDAR_COL_NUM, 1);

            bt.setLayoutParams(params);

            calendar.addView(bt);
        }
    }

    private void show_head() {
        params = new GridLayout.LayoutParams();
        params.columnSpec = GridLayout.spec(2, 3);
        params.rowSpec = GridLayout.spec(0, 1);

        date_title = new TextView(this);
        date_title.setText(dateFormat.format(new Date()).substring(0, 7));
        date_title.setTextSize(25);
        date_title.setGravity(Gravity.CENTER);
        date_title.setLayoutParams(params);
        calendar.addView(date_title);

        params = new GridLayout.LayoutParams();
        params.columnSpec = GridLayout.spec(0, 2);
        params.rowSpec = GridLayout.spec(0, 1);

        Button previous = new Button(this);
        previous.setText("<");
        previous.setTextSize(20);
        previous.setGravity(Gravity.CENTER);
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (--MONTH <= 0) {
                    YEAR--;
                    MONTH = 12;
                }

                CALENDAR_ROW = 0;
                CALENDAR_COL = 0;

                DAYS = daysOfMonthes.getDays(MONTH);

                calendar.removeAllViews();

                show_head();
                show_Calendar();

                setDate_title(YEAR, MONTH);
            }
        });
        previous.setLayoutParams(params);
        calendar.addView(previous);

        params = new GridLayout.LayoutParams();
        params.columnSpec = GridLayout.spec(5, 2);
        params.rowSpec = GridLayout.spec(0, 1);

        Button next = new Button(this);
        next.setText(">");
        next.setTextSize(20);
        next.setGravity(Gravity.CENTER);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (++MONTH > 12) {
                    MONTH = 1;

                    YEAR++;
                }

                CALENDAR_ROW = 0;
                CALENDAR_COL = 0;

                DAYS = daysOfMonthes.getDays(MONTH);

                calendar.removeAllViews();

                show_head();
                show_Calendar();

                setDate_title(YEAR, MONTH);
            }
        });
        next.setLayoutParams(params);
        calendar.addView(next);

        String[] week = {"一", "二", "三", "四", "五", "六", "日"};

        int ROW = 0;
        for (int i = 0; i < 7; i++) {
            params = new GridLayout.LayoutParams();
            TextView tv = new TextView(this);
            tv.setText(week[i]);
            tv.setGravity(Gravity.CENTER);
            params.rowSpec = GridLayout.spec(1, 1);
            params.columnSpec = GridLayout.spec(ROW++, 1);
            tv.setLayoutParams(params);
            calendar.addView(tv);
        }
    }

    private void show_table() {
        String[] title = {"时段", "凌晨", "早晨", "上午", "中午", "下午", "晚上", "深夜", "午夜", "总步数"};

        params = new GridLayout.LayoutParams();

        table_date = new TextView(this);
        table_date.setText(QUERY_DATE + "(" + timing_store_Service.times+ ")");
        table_date.setGravity(Gravity.CENTER);
        params.rowSpec = GridLayout.spec(0, 5);
        params.columnSpec = GridLayout.spec(0, 2);
        params.width = 500;
        table_date.setLayoutParams(params);
        table.addView(table_date);

        for (int i = 0; i < title.length; i++) {
            params = new GridLayout.LayoutParams();

            TextView tv = new TextView(this);
            tv.setText(title[i]);
            params.columnSpec = GridLayout.spec(TABLE_COL, 1);
            params.rowSpec = GridLayout.spec(TABLE_ROW++, 1);
            params.height = 100;
            params.width = 200;
            tv.setLayoutParams(params);
            table.addView(tv);
        }

        params = new GridLayout.LayoutParams();

        TextView walk = new TextView(this);
        walk.setText("步数");
        params.rowSpec = GridLayout.spec(0, 1);
        params.columnSpec = GridLayout.spec(3, 1);
        walk.setLayoutParams(params);
        table.addView(walk);

        int ROW = 1;
        for (int i = 0; i < 9; i++) {
            params = new GridLayout.LayoutParams();
            params.columnSpec = GridLayout.spec(3, 1);
            params.rowSpec = GridLayout.spec(ROW++, 1);
            textViews[i].setLayoutParams(params);
            table.addView(textViews[i]);
        }
    }

    private void setTable_date(String query_date) {
        table_date.setText(query_date + "(" + timing_store_Service.times + ")");
    }

    private void query_stepData() {
        Cursor cursor = db.query("data", null, "date = ?", new String[]{QUERY_DATE},
                null, null, null);

        String beforeDawn = null;
        String morning = null;
        String forenoon = null;
        String noon = null;
        String afternoon = null;
        String night = null;
        String midnight = null;
        String lateAtNight = null;
        String totalSteps = null;

        if (cursor != null) {
            if (cursor.moveToNext()) {
                beforeDawn = cursor.getString(cursor.getColumnIndex("beforeDawn"));
                morning = cursor.getString(cursor.getColumnIndex("morning"));
                forenoon = cursor.getString(cursor.getColumnIndex("forenoon"));
                noon = cursor.getString(cursor.getColumnIndex("noon"));
                afternoon = cursor.getString(cursor.getColumnIndex("afternoon"));
                night = cursor.getString(cursor.getColumnIndex("night"));
                midnight = cursor.getString(cursor.getColumnIndex("midnight"));
                lateAtNight = cursor.getString(cursor.getColumnIndex("lateAtNight"));
                totalSteps = cursor.getString(cursor.getColumnIndex("totalSteps"));
            }

            if (beforeDawn == null) beforeDawn = "--";
            if (morning == null) morning = "--";
            if (forenoon == null) forenoon = "--";
            if (noon == null) noon = "--";
            if (afternoon == null) afternoon = "--";
            if (night == null) night = "--";
            if (midnight == null) midnight = "--";
            if (lateAtNight == null) lateAtNight = "--";
            if (totalSteps == null) totalSteps = "--";

            textViews[0].setText(beforeDawn);
            textViews[1].setText(morning);
            textViews[2].setText(forenoon);
            textViews[3].setText(noon);
            textViews[4].setText(afternoon);
            textViews[5].setText(night);
            textViews[6].setText(midnight);
            textViews[7].setText(lateAtNight);
            textViews[8].setText(totalSteps);

            cursor.close();
        }
    }
}