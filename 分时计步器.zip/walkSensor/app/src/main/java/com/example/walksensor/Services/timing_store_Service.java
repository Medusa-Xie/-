package com.example.walksensor.Services;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.health.TimerStat;
import android.util.AtomicFile;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.baidu.mapsdkplatform.comjni.engine.AppEngine;
import com.example.walksensor.Control.MainActivity;
import com.example.walksensor.DataBase.databaseHelper;
import com.example.walksensor.R;
import com.facebook.stetho.Stetho;

import java.security.cert.PolicyNode;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;

import javax.annotation.CheckForNull;

/**
 * 定时存储服务
 */
public class timing_store_Service extends Service {
    private static final String TAG = "timing_store_Service";

    private static final int DEPARATION = 600;
    private static final int t1 = 72900;
    //    private static final int DEPARATION_CEILING = 5;
    //00:10:00分隔一天
    private static final int BEFROE_DAWN = 18000;
    private static final int t2 = 61200;
    //    private static final int BEFROE_DAWN_CEILING = 18005;
    //05:00:00之前为凌晨
    private static final int MORNING = 28800;
    private static final int t3 = 61500;
    //    private static final int MORNING_CEILING = 28805;
    //8:00:00之前为早晨
    private static final int FORENOON = 39600;
    private static final int t4 = 61800;
    //    private static final int FORENOON_CEILING = 39605;
    //11:00:00之前为上午
    private static final int NOON = 46800;
    private static final int t5 = 62100;
    //    private static final int NOON_CEILING = 46805;
    //13:00:00之前为中午
    private static final int AFTERNOON = 61200;
    private static final int t6 = 47400;
    //    private static final int AFTERNOON_CEILING = 61205;
    //17:00:00之前为下午
    private static final int NIGHT = 68400;
    private static final int t7 = 48000;
    //    private static final int NIGHT_CEILING = 68405;
    //19:00:00之前为晚上
    private static final int MIDNIGHT = 72000;
    private static final int t8 = 48600;
    //    private static final int MIDNIGHT_CEILING = 72005;
    //20:00:00之前为半夜
    private static final int LATE_AT_NIGHT = 86390;
    private static final int t9 = 49200;
    //    private static final int LATE_AT_NIGHT_CEILING = 4971595;
    //23:59:50之前为午夜
    private static final int RANGE = 5;//记录数据的时间范围

    public static int times = 0;

    private static String PATTERN = "";//数据库日期行主键

    private static String date;//日期
    private static SimpleDateFormat dateFormat;//日期显示格式

    private static int now_step = 0;//实时更新的当前行走步数记录
    private static int latest_step = 0;//上一个时段最后的步数记录
    private static int differ_steps = 0;//步数差

    private static int DATA_LINE = 0;//数据底线

    public static PowerManager.WakeLock wakeLock;//电源锁，防止系统进入休眠状态

    private static databaseHelper helper = MainActivity.helper;
    SQLiteDatabase db;

    @Override
    public void onCreate() {
        super.onCreate();

        this.db = helper.getWritableDatabase();

        PowerManager pm = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "wakelock:hhh");
        wakeLock.acquire();//开启电源锁

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setContentTitle("Walk Sensor")
                .setContentText("正在后台运行...")
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.mipmap.ic_launcher)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId("notification_id");
        }

        // 额外添加：
        // 【适配Android8.0】给NotificationManager对象设置NotificationChannel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel channel = new NotificationChannel("notification_id", "notification_name", NotificationManager.IMPORTANCE_LOW);
            notificationManager.createNotificationChannel(channel);
        }

        startForeground(1, builder.build());//启动前台服务防止服务被杀死

        dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        date = dateFormat.format(new Date());

        Cursor cursor = db.query("system_info", null, null, null,
                null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                DATA_LINE = cursor.getInt(cursor.getColumnIndex("data_line"));
                latest_step = cursor.getInt(cursor.getColumnIndex("latest_step"));
            }

            cursor.close();
        }

        Log.i(TAG, "DATA_LINE初始化为" + DATA_LINE);
        Log.i(TAG, "latest_step初始化为" + latest_step);

        PATTERN = date.substring(0, 10);//初始化PATTERN
        Log.i(TAG, "PATTERN初始化为" + PATTERN);

        try {
            insertData(PATTERN);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Log.i("timingTask_", "开始启动");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    private timingBinder mBinder = new timingBinder();

    public class timingBinder extends Binder {
        private MainActivity.timingListener listener;

        public void startTask(final MainActivity.timingListener listener) {
            this.listener = listener;

            new Thread(new Runnable() {
                @Override
                public void run() {
                    Log.i(TAG, "startTask: " + "进入线程");

                    int hour;
                    int min;
                    int sec;
                    int totalTime;

                    while (true) {
                        date = dateFormat.format(new Date());
                        Log.i(TAG, "run: " + "date is " + date);

                        hour = Integer.parseInt(date.substring(11, 13));//获得当前小时
                        min = Integer.parseInt(date.substring(14, 16));//获取当前分钟
                        sec = Integer.parseInt(date.substring(17));//获取当前秒

                        totalTime = toSec(hour, min, sec);//获取当前时间秒数

                        Log.i(TAG, "PATTERN = " + PATTERN);

                        if (totalTime >= DEPARATION && totalTime <= DEPARATION + RANGE) {
                            updateData(now_step, PATTERN, "totalSteps", true);
                            Log.i(TAG, "总步数已更新!");

                            clearSteps();//步数显示器归零、阶段步数清零、数据底线更新
                            Log.i(TAG, "数据已重置!");

                            String today = date.substring(0, 10);//获得当天的日期
                            PATTERN = today;//更新PATTERN

                            insertData(today);
                            Log.i(TAG, "新的一天已插入" + today);

                            times = 0;
                            Log.i(TAG, "更新次数已清零");
                        }

                        if (totalTime >= BEFROE_DAWN && totalTime <= BEFROE_DAWN + RANGE) {
                            updateData(now_step, PATTERN, "beforeDawn", false);

                            Log.i(TAG, "凌晨数据已更新!");
                        }

                        if (totalTime >= MORNING && totalTime <= MORNING + RANGE) {
                            updateData(now_step, PATTERN, "morning", false);

                            Log.i(TAG, "早晨数据已更新!");
                        }

                        if (totalTime >= FORENOON && totalTime <= FORENOON + RANGE) {
                            updateData(now_step, PATTERN, "forenoon", false);

                            Log.i(TAG, "上午数据已更新!");
                        }

                        if (totalTime >= NOON && totalTime <= NOON + RANGE) {
                            updateData(now_step, PATTERN, "noon", false);

                            Log.i(TAG, "中午数据已更新!");
                        }

                        if (totalTime >= AFTERNOON && totalTime <= AFTERNOON + RANGE) {
                            updateData(now_step, PATTERN, "afternoon", false);

                            Log.i(TAG, "下午数据已更新!");
                        }

                        if (totalTime >= NIGHT && totalTime <= NIGHT + RANGE) {
                            updateData(now_step, PATTERN, "night", false);

                            Log.i(TAG, "晚上数据已更新!");
                        }

                        if (totalTime >= MIDNIGHT && totalTime <= MIDNIGHT + RANGE) {
                            updateData(now_step, PATTERN, "midnight", false);

                            Log.i(TAG, "半夜数据已更新!");
                        }

                        if (totalTime >= LATE_AT_NIGHT  && totalTime <= LATE_AT_NIGHT + RANGE) {
                            updateData(now_step, PATTERN, "lateAtNight", false);

                            Log.i(TAG, "午夜数据已更新!");
                        }

                        try {
                            Thread.sleep(5000);//休眠对应的范围时间
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
        }

        public void record(int steps) {
            setNow_step(steps);//更新task的记录步数

            Log.i(TAG, "task实时步数已更新");
        }

        private void clearSteps() {
            latest_step = 0;//当天数据清零

            ContentValues values = new ContentValues();
            values.put("data_line", now_step);
            values.put("latest_step", latest_step);

            db.update("system_info", values, null, null);

            DATA_LINE = now_step;

            listener.reset_CallBack();//回调,更新步数显示器
        }

        public void setNow_step(int steps) {
            now_step = steps;

            listener.show_CallBack(DATA_LINE);//回调接口，更新步数显示

            Log.i(TAG, "setNow_step: " + now_step);
        }

        private int toSec(int hour, int min, int sec) {
            Log.i(TAG, "hour is " + hour + " min is " + min + " sec is " + sec + " result is " + (hour * 3600 + min * 60 + sec));

            return hour * 3600 + min * 60 + sec;
        }
    }

    private void insertData(String today) {
        ContentValues values = new ContentValues();
        values.put("date", today);

        db.insert("data", null, values);
    }

    private void updateData(int newdata, String pattern, String db_colomn, boolean isTotal) {
        times++;//数据更新次数增加1

        Log.i(TAG, "updateData: " + "new data " + newdata);

        differ_steps = newdata - DATA_LINE;
        if (!isTotal) differ_steps -= latest_step;
        //步数差为：传感器传回的数据-当天数据底线-最近一次记录的步数

        Log.i(TAG, "updateData: " + "differ steps " + differ_steps);

        ContentValues values = new ContentValues();
        values.put(db_colomn, differ_steps);

        db.update("data", values, "date = ?", new String[]{pattern});
        //更新数据库

        if (differ_steps != 0) {
            latest_step = newdata - DATA_LINE;//更新最近一次记录的步数

            ContentValues values1 = new ContentValues();
            values1.put("latest_step", latest_step);

            db.update("system_info", values1, null, null);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
}