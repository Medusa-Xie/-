package com.example.walksensor.Control;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewPropertyAnimatorListener;

import android.Manifest;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import com.example.walksensor.Services.*;
import com.example.walksensor.DataBase.*;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.CoordType;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.trace.Trace;
import com.baidu.trace.LBSTraceClient;
import com.baidu.trace.model.OnTraceListener;
import com.baidu.trace.model.PushMessage;
import com.example.walksensor.R;
import com.facebook.stetho.Stetho;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private static final String TAG = "MainActivity";

    private SensorManager mSensorManager;//传感器管理器
    private Sensor stepSensor;//计步器

    private float steps = 0;//步数

    private TextView step_View;//步数显示

    private double last_step = 0;//最近一次记录的步数
    private double last_time;//最近一次记录的时间

    public static databaseHelper helper;

    private timing_store_Service.timingBinder mBinder;

    private MapView mMapView;

    // 轨迹服务ID
    long serviceId = 0;
    // 设备标识
    String entityName = "myTrace";
    // 是否需要对象存储服务，默认为：false，关闭对象存储服务。
    // 注：鹰眼 Android SDK v3.0以上版本支持随轨迹上传图像等对象数据，若需使用此功能，该参数需设为 true，
    // 且需导入bos-android-sdk-1.0.2.jar。
    boolean isNeedObjectStorage = true;
    // 初始化轨迹服务
    Trace mTrace;
    // 初始化轨迹服务客户端
    LBSTraceClient mTraceClient;

    BaiduMap mBaiduMap;

    LocationClient mLocationClient;

    /**
     * 回调接口，当步数重置时回调该方法
     */
    public interface timingListener {
        void reset_CallBack();//重置回调接口

        void show_CallBack(int line);//更新步数显示面板回调接口
    }

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (mBinder == null) {
                mBinder = (timing_store_Service.timingBinder) service;

                mBinder.startTask(new timingListener() {
                    @Override
                    public void reset_CallBack() {
                        step_View.setText(String.valueOf(0));
                        //很奇怪的问题：setText方法传入一个非String类型参数并不会报错但是会导致程序崩溃!!!
                    }

                    @Override
                    public void show_CallBack(int line) {
                        step_View.setText(String.valueOf((int) (steps - line)));
                    }
                });

                Log.i(TAG, "已绑定服务");
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.i(TAG, "服务已解除绑定");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //在使用SDK各组件之前初始化context信息，传入ApplicationContext
        SDKInitializer.initialize(getApplicationContext());
        //自4.3.0起，百度地图SDK所有接口均支持百度坐标和国测局坐标，用此方法设置您使用的坐标类型.
        //包括BD09LL和GCJ02两种坐标，默认是BD09LL坐标。
        SDKInitializer.setCoordType(CoordType.BD09LL);

        setContentView(R.layout.activity_main);

        step_View = (TextView) findViewById(R.id.step_View);

        Button toMe = (Button) findViewById(R.id.toMe);
        toMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, user_record.class);

                startActivity(intent);
            }
        });

        List<String> permissionList = new ArrayList<>();

        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            permissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);

        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED)
            permissionList.add(Manifest.permission.INTERNET);

        if (!permissionList.isEmpty()) {
            String[] permission = permissionList.toArray(new String[permissionList.size()]);

            ActivityCompat.requestPermissions(MainActivity.this, permission, 1);
        } else {
            initalize();
        }
    }

    @Override
    public void onRequestPermissionsResult(int resultCode, String[] permissions, int[] grantResult) {
        switch (resultCode) {
            case 1:
                if (grantResult.length > 0) {
                    for (int result : grantResult) {
                        if (result != PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(this, "您必须同意所有权限", Toast.LENGTH_SHORT).show();

                            finish();
                        }
                    }
                    initalize();
                } else {
                    Toast.makeText(this, "发生未知错误", Toast.LENGTH_SHORT).show();

                    finish();
                }
        }
    }

    private void initalize() {
        initDataBase();//初始化数据库

        startService();//初始化存储记录服务

        initBDMap();//初始化百度地图

        initEagleEye();//初始化鹰眼追踪

        initSensor();//初始化计步器
    }

    private void startService() {
        Intent startIntent = new Intent(this, timing_store_Service.class);
        startService(startIntent);//启动服务
        bindService(startIntent, serviceConnection, BIND_AUTO_CREATE);//绑定服务
    }

    private void initDataBase() {
        Stetho.initializeWithDefaults(this);//数据库可视化插件

        this.helper = new databaseHelper(this, "data_Logging.db", null, 1);
    }

    private void initBDMap() {
        //获取地图控件引用
        mMapView = (MapView) findViewById(R.id.bmapView);
        mBaiduMap = mMapView.getMap();
        mBaiduMap.setMyLocationEnabled(true);

        //定位初始化
        mLocationClient = new LocationClient(this);

        //通过LocationClientOption设置LocationClient相关参数
        LocationClientOption option = new LocationClientOption();
        option.setOpenGps(true); // 打开gps
        option.setCoorType("bd09ll"); // 设置坐标类型
        option.setScanSpan(1000);

        //设置locationClientOption
        mLocationClient.setLocOption(option);

        //注册LocationListener监听器
        MyLocationListener myLocationListener = new MyLocationListener();
        mLocationClient.registerLocationListener(myLocationListener);
        //开启地图定位图层
        mLocationClient.start();
    }

    private void navigateTo(BDLocation location) {
        com.baidu.mapapi.model.LatLng latLng =
                new com.baidu.mapapi.model.LatLng(location.getLatitude(), location.getLongitude());
        MapStatusUpdate update = MapStatusUpdateFactory.newLatLng(latLng);
        mBaiduMap.animateMapStatus(update);

//        update = MapStatusUpdateFactory.zoomTo(16f);
//        mBaiduMap.animateMapStatus(update);
    }

    private void initEagleEye() {
        mTraceClient = new LBSTraceClient(getApplicationContext());
        mTrace = new Trace(serviceId, entityName, isNeedObjectStorage);

        // 定位周期(单位:秒)
        int gatherInterval = 5;
        // 打包回传周期(单位:秒)
        int packInterval = 10;
        // 设置定位和打包周期
        mTraceClient.setInterval(gatherInterval, packInterval);

        // 初始化轨迹服务监听器
        OnTraceListener mTraceListener = new OnTraceListener() {
            @Override
            public void onBindServiceCallback(int i, String s) {
            }

            // 开启服务回调
            @Override
            public void onStartTraceCallback(int status, String message) {
            }

            // 停止服务回调
            @Override
            public void onStopTraceCallback(int status, String message) {
            }

            // 开启采集回调
            @Override
            public void onStartGatherCallback(int status, String message) {
            }

            // 停止采集回调
            @Override
            public void onStopGatherCallback(int status, String message) {
            }

            // 推送回调
            @Override
            public void onPushCallback(byte messageNo, PushMessage message) {
            }

            @Override
            public void onInitBOSCallback(int i, String s) {
            }
        };

        mTraceClient.startTrace(mTrace, mTraceListener);
        mTraceClient.startGather(mTraceListener);
    }

    /**
     * 我们通过继承抽象类BDAbstractListener并重写其onReceieveLocation方法来获取定位数据，并将其传给MapView。
     */
    public class MyLocationListener extends BDAbstractLocationListener {
        @Override
        public void onReceiveLocation(BDLocation location) {
            //mapView 销毁后不在处理新接收的位置
            if (location == null || mMapView == null) {
                return;
            }

            if (location.getLocType() == BDLocation.TypeGpsLocation
                    || location.getLocType() == BDLocation.TypeNetWorkException)
                navigateTo(location);

            MyLocationData locData = new MyLocationData.Builder()
                    .accuracy(location.getRadius())
                    // 此处设置开发者获取到的方向信息，顺时针0-360
                    .direction(location.getDirection()).latitude(location.getLatitude())
                    .longitude(location.getLongitude()).build();
            mBaiduMap.setMyLocationData(locData);
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        last_time = System.currentTimeMillis();
        //在activity执行onResume时执行mMapView. onResume ()，实现地图生命周期管理
        mMapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView. onPause ()，实现地图生命周期管理
        mMapView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //在activity执行onDestroy时执行mMapView.onDestroy()，实现地图生命周期管理
        mMapView.onDestroy();

        mBaiduMap.setMyLocationEnabled(false);

        Intent stopIntent = new Intent(this, timing_store_Service.class);
        stopService(stopIntent);//终止服务

        unbindService(serviceConnection);

        timing_store_Service.wakeLock.release();//关闭电源锁
    }

    /**
     * 获取传感器服务，获取计步器
     */
    private void initSensor() {
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);//获取传感服务——SensorManager实例

        List<Sensor> sensors = mSensorManager.getSensorList(Sensor.TYPE_ALL);//获取该设备支持的所有传感器列表
        Log.i("该设备支持", sensors.size() + "种传感器");

        for (Sensor next : sensors) Log.i("Sensor_", next.getName());//打印支持的传感器列表

        stepSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);//获取计步器

        if (stepSensor != null)
            mSensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI);
            //注册监听器，最后一个参数为采样频率
        else
            Log.i("fail:", "未找到计步器");
    }

    /**
     * SensorEventListener回调接口，当sensor记录的数据改变时，回调该方法
     *
     * @param event SensorEvent实例
     */
    @Override
    public void onSensorChanged(SensorEvent event) {
        this.steps = event.values[0];

        if (mBinder != null) mBinder.record((int) steps);//每次传感器回传就更新task数据
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        Log.i("", "onAccuracyChanged");
    }
    }
