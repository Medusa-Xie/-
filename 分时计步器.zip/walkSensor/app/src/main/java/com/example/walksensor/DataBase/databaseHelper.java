package com.example.walksensor.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class databaseHelper extends SQLiteOpenHelper {
    private static final String CREATE_DATA = "create table data(" +
            "date text primary key, " +
            "beforeDawn text, " +
            "morning text, " +
            "forenoon text, " +
            "noon text, " +
            "afternoon text, " +
            "night text, " +
            "midnight text, " +
            "lateAtNight text, " +
            "totalSteps text)";

    private static final String CREATE_SYSTEM_INFO = "create table system_info(" +
            "data_line integer, " +
            "latest_step integer)";

    private Context mContext;

    public databaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);

        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_DATA);
        db.execSQL(CREATE_SYSTEM_INFO);

        ContentValues values = new ContentValues();
        values.put("data_line", 0);
        values.put("latest_step", 0);

        db.insert("system_info", null, values);

        Log.i("database_", "已创建数据库");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i("database", "升级数据库");
    }
}
