package com.example.test1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button login;
    private Button lint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = findViewById(R.id.loginDialog);
        lint = findViewById(R.id.lintDialog);

        lint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Hello World!");
                builder.setMessage("Good Morning Android!");
                builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "您点击了取消按钮", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "您点击了确定按钮", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.create().show();
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*从另外的布局中关联组件*/
                View loginView = getLayoutInflater().inflate(R.layout.login, null);

                final EditText username = loginView.findViewById(R.id.inputUserName);
                final EditText password = loginView.findViewById(R.id.inputPassWord);

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("请登录");
                builder.setView(loginView);
                builder.setPositiveButton("登录", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (username.getText().toString().equals("abc")
                                && password.getText().toString().equals("123"))
                            Toast.makeText(MainActivity.this, "登陆成功",
                                    Toast.LENGTH_SHORT).show();
                        else
                            Toast.makeText(MainActivity.this, "用户名或者密码错误",
                                    Toast.LENGTH_SHORT).show();
                    }
                });
                builder.create().show();
            }
        });
    }
}
