package com.example.mediaPlayer.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class databaseHelper extends SQLiteOpenHelper {
    private String CREATE_music = "create table music(" +
            "id integer primary key autoincrement, " +
            "name text unique, " +
            "singer text, " +
            "album text, " +
            "duration text, " +
            "uri text)";

    private Context context;

    public databaseHelper(Context context, String string, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, string, factory, version);

        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_music);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists music");

        onCreate(db);
    }
}
