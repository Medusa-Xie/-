package com.example.mediaPlayer.database;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

/**
 * 用单独文件记录数据库当前的版本号
 * 否则每次kill掉进程，再次启动程序时，由于数据库版本号不对应将会导致程序崩溃！
 */
public class version_info {
    private static int version;//记录数据库版本

    /**
     * 从文件中读取数据库保存的版本号
     * @param fileName 目标文件路径
     */
    public static void readFile(String fileName) {
        File file = new File(fileName);

        InputStream inputStream = null;
        Reader reader = null;
        BufferedReader bufferedReader = null;

        try {
            inputStream = new FileInputStream(file);
            reader = new InputStreamReader(inputStream);
            bufferedReader = new BufferedReader(reader);

            String result = "";

            while ((result = bufferedReader.readLine()) != null) {
                version = Integer.parseInt(result);//版本等于从文件中读取到的字符串
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (inputStream != null) inputStream.close();

                if (reader != null) reader.close();

                if (bufferedReader != null) bufferedReader.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 将数据库版本号写入到文件中进行保存
     * @param fileName 目标文件路径
     * @param version 版本号
     */
    public static void writeFile(String fileName, String version) {
        try {
            FileWriter fileWriter = new FileWriter(fileName, false);

            fileWriter.write(version);

            fileWriter.flush();//写入文档中

            fileWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取文件中记录的版本号
     * @return 数据库当前版本号
     */
    public static int getVersion() {
        return version;
    }
}


