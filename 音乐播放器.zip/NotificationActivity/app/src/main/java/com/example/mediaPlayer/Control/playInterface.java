package com.example.mediaPlayer.Control;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mediaPlayer.Model.getLrc;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.mediaPlayer.Model.MediaInfo;
import com.example.mediaPlayer.R;

import java.util.List;

public class playInterface extends AppCompatActivity implements View.OnClickListener,
        SeekBar.OnSeekBarChangeListener {
    private static MediaPlayer mediaPlayer = MainActivity.getMediaPlayer();

    private static List<MediaInfo> list = MainActivity.getList();//获取播放列表
    static String now_music = "";//播放歌曲的路径
    static int location = 0;//播放歌曲的位置

    public static String PLAY_MODEL = "循环播放";
    public static String MUSIC_PLAY = "";//当前正在播放的音乐名称

    public static final int UPDATE_PROGRESS = 1;//更新进度条进度消息
    public static final int OBTAIN_LYRIC = 2;//获取歌词回调消息

    SeekBar seekBar;
    TextView current_tv;
    TextView total_tv;

    static TextView lyrics;

    Button to_play;

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case UPDATE_PROGRESS:
                    int progress = mediaPlayer.getCurrentPosition();

                    seekBar.setProgress(progress);

                    current_tv.setText(time(progress + ""));

                    updataProgress();

                    break;
                case OBTAIN_LYRIC:
                    if (!getLrc.lyric.equals("")) lyrics.setText(getLrc.lyric);

                    break;
                default:
            }

            return true;
        }
    });

    private void updataProgress() {
        Message msg = new Message();
        msg.what = UPDATE_PROGRESS;
        handler.sendMessageDelayed(msg, 1000);
        /*
        更新音乐进度条进度，每隔1s发送一个更新消息，当handler收到消息后即更新进度条
         */
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_interface);

        now_music = MainActivity.now_music;
        location = MainActivity.location;
        //获取音乐播放器正在播放的音乐路径和位于播放列表的位置

        seekBar = findViewById(R.id.seekbar);
        current_tv = findViewById(R.id.current_time_tv);
        total_tv = findViewById(R.id.total_time_tv);
        lyrics = findViewById(R.id.lyrics);

        to_play = findViewById(R.id.to_play);

        MUSIC_PLAY = list.get(location).getName();

        Button play = findViewById(R.id.play_or_pause);
        Button order = findViewById(R.id.play_order);
        Button next = findViewById(R.id.next);
        Button previous = findViewById(R.id.previous);

        order.setText(PLAY_MODEL);//显示目前播放模式

        play.setOnClickListener(this);
        order.setOnClickListener(this);
        next.setOnClickListener(this);
        previous.setOnClickListener(this);

        initProgress();

        updataProgress();

        seekBar.setOnSeekBarChangeListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();

        show_lyrics();
        //为每首歌曲加载歌词
    }

    @Override
    public void onClick(View view) {
        Button bt = findViewById(R.id.play_or_pause);

        switch (view.getId()) {
            case R.id.play_or_pause:
                if (!mediaPlayer.isPlaying()) {
                    mediaPlayer.start();

                    bt.setText("暂停");
                } else {
                    mediaPlayer.pause();

                    bt.setText("播放");
                }

                break;
            case R.id.play_order:
                Button order = findViewById(R.id.play_order);

                if (PLAY_MODEL.equals("循环播放")) {
                    order.setText("随机播放");

                    PLAY_MODEL = "随机播放";
                } else {
                    order.setText("循环播放");

                    PLAY_MODEL = "循环播放";
                }

                break;
            case R.id.next:
                changeMusic();

                break;

            case R.id.previous:
                previous();

                break;
            default:
                break;
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    /**
     * 当手指停止在进度条上拖拽之后执行的方法（同步与进度条一致的进度）
     *
     * @param seekBar 目标进度条
     */
    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        int progress = seekBar.getProgress();

        mediaPlayer.seekTo(progress);
    }

    private void initProgress() {
        String duration = list.get(location).getTime();

        seekBar.setProgress(0);//重置进度条进度
        seekBar.setMax(Integer.parseInt(duration));//设置进度条最大进度为歌曲时长
        total_tv.setText(time(duration));//显示总时长
    }

    public void changeMusic() {
        if (PLAY_MODEL.equals("循环播放")) {
            try {
                next();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (PLAY_MODEL.equals("随机播放")) {
            int play_num = (int) (Math.random() * list.size());

            location = play_num;
            now_music = list.get(location).getUri();

            MUSIC_PLAY = list.get(location).getName();

            MainActivity.now_music = now_music;
            MainActivity.location = location;

            show_lyrics();

            Log.d("random number", location + "");

            MainActivity.initMediaPlayer(now_music);
        }
    }

    public void next() {
        if (location + 1 >= list.size()) location = -1;//按照列表重新开始播放

        now_music = list.get(++location).getUri();

        MUSIC_PLAY = list.get(location).getName();

        MainActivity.now_music = now_music;
        MainActivity.location = location;

        show_lyrics();

        MainActivity.initMediaPlayer(now_music);

        mediaPlayer.start();
    }
    //按照列表顺序从上至下依次播放音乐

    private void previous() {
        if (location - 1 < 0) location = list.size();

        now_music = list.get(--location).getUri();

        MUSIC_PLAY = list.get(location).getName();

        show_lyrics();

        MainActivity.location = location;
        MainActivity.now_music = now_music;

        MainActivity.initMediaPlayer(now_music);

        mediaPlayer.start();
    }

    public static String time(String time) {
        if (time.length() <= 3) return "00:00";

        if (time.length() == 4) time = time.substring(0, 1);
        else if (time.length() == 5) time = time.substring(0, 2);
        else
            time = time.substring(0, 3);

        int result = Integer.parseInt(time);
        int duplicate = result;//result的副本

        int minute = result / 60;
        int second = duplicate % 60;

        if ((minute + "").length() == 1 && (second + "").length() == 1)
            return "0" + minute + ":" + "0" + second;

        if ((minute + "").length() == 1) return "0" + minute + ":" + second;

        if ((second + "").length() == 1) return minute + ":" + "0" + second;

        return minute + ":" + second;
    }

    public void show_lyrics() {
        lyrics.setText("正在获取歌词...");

        new Thread(new Runnable(){
            @Override
            public void run() {
                getLrc.requestLrcData(list.get(location).getName());

                Message message = new Message();
                message.what = playInterface.OBTAIN_LYRIC;
                handler.sendMessageDelayed(message, 3000);
                /*
                当从服务器获取完歌词后，向handler发送一条消息，表明歌词获取已完成，即更新歌词显示的textView
                 */
            }
        }).start();
        /*
        从网络请求数据不能放在主线程中，不然会报错
        必须在manifest上允许系统在运行条用远程网络接口时允许使用明文通信（android新安全策略）
         */
    }
}
