package com.example.mediaPlayer.Control;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mediaPlayer.Model.MediaInfo;
import com.example.mediaPlayer.R;

import java.util.ArrayList;
import java.util.List;

public class banch_managment extends AppCompatActivity {
    private List<MediaInfo> list = new ArrayList<>();
    private List<MediaInfo> delete_items = new ArrayList<>();//记录要删除的音乐id
    private boolean[] selected;//记录listview中被选中的item

    private com.example.mediaPlayer.database.databaseHelper databaseHelper = MainActivity.databaseHelper;

    ListView listView;
    private banchAdapter adapter;

    class banchAdapter extends ArrayAdapter<MediaInfo> {
        private int resourceId;

        banch_ViewHolder viewHolder;

        class banch_ViewHolder {
            TextView song_name;
            TextView song_singerAndAlbum;
            TextView selected;
        }

        public banchAdapter(Context context, int textViewResourceId, List<MediaInfo> objects) {
            super(context, textViewResourceId, objects);

            resourceId = textViewResourceId;
        }

        /**
         * 滚动ListView时更新视图
         *
         * @return 更新后的视图
         */
        @Override
        public View getView(int position, View converView, ViewGroup parent) {
            MediaInfo media = getItem(position);
            View view;

            if (converView == null) {
                view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);

                viewHolder = new banch_ViewHolder();

                viewHolder.song_name = (TextView) view.findViewById(R.id.banch_name);
                viewHolder.song_singerAndAlbum = (TextView) view.findViewById(R.id.banch_singerAndAlbum);
                viewHolder.selected = (TextView) view.findViewById(R.id.selected);

                view.setTag(viewHolder);
            } else {
                view = converView;

                viewHolder = (banch_ViewHolder) view.getTag();
            }

            if (selected[position]) viewHolder.selected.setVisibility(View.VISIBLE);
            else
                viewHolder.selected.setVisibility(View.INVISIBLE);
            //如果在重绘ListView的过程中，在selected数组中当前position位置为true则显示X标记否则不显示X标记

            viewHolder.song_name.setText(media.getName());
            viewHolder.song_singerAndAlbum.setText(media.getSinger() + "-" + media.getAlubm());

            return view;
        }
    }

    private void initListView() {
        adapter = new banchAdapter(this, R.layout.banch_item, list);

        listView = (ListView) findViewById(R.id.banch_listview);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MediaInfo media = list.get(position);

                selected[position] = true;

                if (delete_items.contains(media)) {
                    delete_items.remove(media);

                    selected[position] = false;

                    Toast.makeText(banch_managment.this, "取消删除——" + media.getName(),
                            Toast.LENGTH_SHORT).show();
                } else {
                    delete_items.add(media);

                    Toast.makeText(banch_managment.this, "删除——" + media.getName(),
                            Toast.LENGTH_SHORT).show();
                    //如果用户重复点击某一个项目，则取消删除（从delete_items中移除）
                }

                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banch_managment);

        list.addAll(MainActivity.list);

        selected = new boolean[list.size()];

        initListView();

        final Button delete = findViewById(R.id.delete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = databaseHelper.getWritableDatabase();

                for (int i = 0; i < delete_items.size(); i++)
                    db.delete("music", "name = ?", new String[]{delete_items.get(i).getName()});

                list.removeAll(delete_items);

                selected = new boolean[list.size()];//重置selected数组

                adapter.notifyDataSetChanged();

                Toast.makeText(banch_managment.this, "删除完成", Toast.LENGTH_SHORT).show();
            }
        });

        Button exit = findViewById(R.id.exit);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        delete_items.clear();//重置删除列表
    }
}
