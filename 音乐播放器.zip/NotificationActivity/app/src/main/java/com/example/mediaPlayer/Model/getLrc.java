package com.example.mediaPlayer.Model;

import com.example.mediaPlayer.Control.playInterface;

import android.os.Message;
import android.util.Log;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * 获取音乐歌词
 */
public class getLrc {
    public static String lyric = "获取歌词失败";

    /**
     * 调用”歌词迷”API获取到对应歌曲的网络数据
     *
     * @param name 目标歌曲名称
     */
    public static void requestLrcData(final String name) {
        OkHttpClient client = new OkHttpClient();
        //okhttp:一个处理网络请求的开源项目,是安卓端最火热的轻量级框架

        String titile = name.trim();

        Log.i("song_name", titile);

        String target = "http://gecimi.com/api/lyric/" + titile;
        Log.i("api", target);

        Request request = new Request.Builder()
                .url(target)
                .build();
        /*
        构建一个提交到url处的请求
         */

        client.newCall(request).enqueue(new Callback() {//必须申请网络权限才会接收到返回数据，否则一直调用onFailure方法
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d("callback", "Fail");
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String responseStr = response.body().string();

                Log.d("callback:", "onResponse: " + responseStr);

                parseJSON(responseStr, 0);
            }
        });
        /*
        将request发送，并接受从远程网络接口callback的数据response
         */
    }

    /**
     * 从传回的数据中获取JSON格式数据，并取得在其中的某个歌词文件url，如果查找的歌曲没有歌词则返回空
     *
     * @param response 回传数据
     * @param c        目标位置
     * @return 歌词文件url
     */
    public static void parseJSON(String response, int c) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            //JSON是一种轻量级的数据交换格式，采用完全独立于编程语言的文本格式来存储和表示数据，
            // 易于人阅读和编写，同时也易于机器解析和生成，并有效地提升网络传输效率。

            int count = Integer.parseInt(jsonObject.getString("count"));
            //获取jsonObject中“count”项中的内容，即歌词数目

            Log.i("count:", count + "");

            if (c <= count) {
                JSONArray jsonArray = new JSONArray(jsonObject.getString("result"));
                //获取jsonObject中“result”项中的内容，由于该项目中的数据为一个数组，因此保存为jsonArray

                jsonObject = jsonArray.getJSONObject(c);
                //从jsonArray中获得对应下标为c的数据

                String url = jsonObject.getString("lrc");

                Log.i("target_url", url);

                showLyric(url);
            }
        } catch (Exception e) {
            Log.d("error", "有错误");
            e.printStackTrace();
        }
    }

    /**
     * 从解析出来的url获取歌词文件
     *
     * @param Url 目标url
     * @return 完整歌词字符串
     */
    public static void showLyric(final String Url) {
        if (Url.equals(""))
            Log.i("empty_url", "there is none any available url!");
        /*
        如果接收到的url为空则返回一个空字符串
         */

        try {
            Log.i("location", "now_showLyric");

            URL url = new URL(Url);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            Log.i("connection", "establish_connection");
            /*
            HttpURLConnection是一种多用途、轻量极的HTTP客户端，使用它来进行HTTP操作可以适用于大多数的应用程序
            url对象通过openConnection方法获取一个HttpURLConnection对象
             */

//            conn.setDoInput(true);
//            Log.i("connection", "set_input");

            conn.setRequestMethod("GET");
            Log.i("connection", "request_method");
            /*
            设置conn的请求使用的方法为GET
             */

            InputStream input = conn.getInputStream();
            Log.i("connection", "get_inputStream");
            /*
            获取从服务器返回的输入流
             */

            lyric = "";

            BufferedReader in = new BufferedReader(new InputStreamReader(input));

            String line = "";//每一行读取到的歌词

            while ((line = in.readLine()) != null) {//逐行读取
                if (line.trim().equals(""))
                    continue;

                lyric += line + "\r\n";

                Log.i("first", "getLrcFromAssets: " + lyric);
            }

            Log.i("total", "getLrcFromAssets: " + lyric);
        } catch (Exception e) {
            Log.i("error", "获取歌词失败");

            e.printStackTrace();
        }
    }
}
