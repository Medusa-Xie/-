package com.example.mediaPlayer.Control;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mediaPlayer.Model.MediaInfo;
import com.example.mediaPlayer.R;
import com.example.mediaPlayer.database.databaseHelper;
import com.facebook.stetho.Stetho;
import com.example.mediaPlayer.database.version_info;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static MediaPlayer mediaPlayer = new MediaPlayer();

    private ListView listView;
    private songsAdapter songsAdapter;

    public static com.example.mediaPlayer.database.databaseHelper databaseHelper;
    public static int version;//数据库版本号

    static String now_music = "";//播放歌曲的路径
    static int location = 0;//播放歌曲的位置

    public static List<MediaInfo> list = new ArrayList<>();//音乐列表

    File file;

    static Button to_play;

    /**
     * ListView适配器
     */
    class songsAdapter extends ArrayAdapter<MediaInfo> {
        private int resourceId;

        class ViewHolder {
            TextView song_name;
            TextView song_singerAndAlbum;
        }

        public songsAdapter(Context context, int textViewResourceId, List<MediaInfo> objects) {
            super(context, textViewResourceId, objects);

            resourceId = textViewResourceId;
        }

        /**
         * 滚动ListView时更新视图
         *
         * @return 更新后的视图
         */
        @Override
        public View getView(int position, View converView, ViewGroup parent) {
            MediaInfo media = getItem(position);
            View view;
            ViewHolder viewHolder;

            if (converView == null) {
                view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);

                viewHolder = new ViewHolder();

                viewHolder.song_name = (TextView) view.findViewById(R.id.song_name);
                viewHolder.song_singerAndAlbum = (TextView) view.findViewById(R.id.song_singerAndAlbum);

                view.setTag(viewHolder);
            } else {
                view = converView;

                viewHolder = (ViewHolder) view.getTag();
            }

            viewHolder.song_name.setText(media.getName());
            viewHolder.song_singerAndAlbum.setText(media.getSinger() + "-" + media.getAlubm());

            return view;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        file = new File(getFilesDir(), "database_version");
        //获取程序根目录并在根目录下创建“database_version”文件，用于记录数据库版本号

        if (!file.exists()) version = 1;//如果文件不存在则初始化数据库初始版本号
        else {
            version_info.readFile(file.getAbsolutePath());
            version = version_info.getVersion();
        }
        //如果文件存在则从文件中读取数据库目前的版本号

        databaseHelper = new databaseHelper(this, "Music.db", null, version);

        Log.d("version_info", file.getAbsolutePath() + ":" + version);

        listView = findViewById(R.id.songs_list);

        getMusicList();//丛程序数据库中获取音乐列表

        songsAdapter = new songsAdapter(this, R.layout.song_item, list);
        songsAdapter.notifyDataSetChanged();

        Stetho.initializeWithDefaults(this);//Chrome上查看数据库插件

        List<String> permissionList = new ArrayList<>();

        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED)
            permissionList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.INTERNET)
                != PackageManager.PERMISSION_GRANTED)
            permissionList.add(Manifest.permission.INTERNET);

        if (!permissionList.isEmpty()) {
            String[] permissions = permissionList.toArray(new String[permissionList.size()]);

            ActivityCompat.requestPermissions(MainActivity.this, permissions, 1);
        } else {
            initMediaList();
        }

        to_play = findViewById(R.id.to_play);

        to_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (now_music.equals("")) return;

                Intent intent = new Intent(MainActivity.this, playInterface.class);

                startActivity(intent);
            }
        });

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                new playInterface().changeMusic();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.scan_local:
                getLocalData();

                initMediaList();

                Toast.makeText(this, "扫描完成", Toast.LENGTH_SHORT).show();

                break;

            case R.id.banch_managment:
                Intent intent = new Intent(MainActivity.this, banch_managment.class);

                startActivity(intent);

                break;

            case R.id.help:
                Intent intentH = new Intent(MainActivity.this, HelpPage.class);

                startActivity(intentH);

                break;
        }

        return true;
    }

    @Override
    public void onResume() {
        super.onResume();

        getMusicList();

        initMediaList();

        to_play.setText(playInterface.MUSIC_PLAY);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0) {
                    for (int result : grantResults) {
                        if (result != PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(MainActivity.this, "您必须同意所有权限才能运行程序！",
                                    Toast.LENGTH_SHORT);

                            finish();
                        }
                    }

                    initMediaList();
                } else {
                    Toast.makeText(this, "发生未知错误", Toast.LENGTH_SHORT).show();

                    finish();
                }

                break;
            default:
                break;
        }
    }

    private void initMediaList() {
        listView.setAdapter(songsAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                location = i;
                now_music = list.get(i).getUri();

                initMediaPlayer(now_music);
            }
        });
    }

    /**
     * 查找手机内部存储中的多媒体数据
     *
     * @return 手机内部存储的音频List
     */
    public void getLocalData() {
        list.clear();//重置音乐列表

        databaseHelper = new databaseHelper(this, "Music.db", null, ++version);//数据库更新
        version_info.writeFile(file.getAbsolutePath(), version + "");
        //数据库更新
        //数据库版本文件信息记录更新
        version_info.readFile(file.getAbsolutePath());

        Log.d("version_info", version_info.getVersion() + "");

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null,
                null, null, MediaStore.Audio.Media.DEFAULT_SORT_ORDER);

        int Media_id = cursor.getColumnIndex(MediaStore.Audio.Media._ID);
        int Media_name = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
        int Media_alubm = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
        int Media_singer = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
        int Media_time = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
        int uri = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(Media_id);
                String name = cursor.getString(Media_name);
                String album = cursor.getString(Media_alubm);
                String singer = cursor.getString(Media_singer);
                String time = cursor.getString(Media_time);
                String path = cursor.getString(uri);

                MediaInfo mediaInfo = new MediaInfo(id, name, album, singer, time, path);

                Log.d("Info", mediaInfo.showInfo());

                if (singer == null) continue;

                ContentValues values = new ContentValues();
                values.put("name", name);
                values.put("singer", singer);
                values.put("album", album);
                values.put("duration", time);
                values.put("uri", path);

                db.insert("music", null, values);

                list.add(mediaInfo);
            }

            cursor.close();
        }
    }

    public void getMusicList() {
        list.clear();//重置音乐列表

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        Cursor cursor = db.query("music", null, null, null,
                null, null, null);

        int Media_id = cursor.getColumnIndex("id");
        int Media_name = cursor.getColumnIndex("name");
        int Media_alubm = cursor.getColumnIndex("album");
        int Media_singer = cursor.getColumnIndex("singer");
        int Media_time = cursor.getColumnIndex("duration");
        int uri = cursor.getColumnIndex("uri");

        if (cursor != null) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(Media_id);
                String name = cursor.getString(Media_name);
                String album = cursor.getString(Media_alubm);
                String singer = cursor.getString(Media_singer);
                String time = cursor.getString(Media_time);
                String path = cursor.getString(uri);

                MediaInfo mediaInfo = new MediaInfo(id, name, album, singer, time, path);

                if (singer == null) continue;

                list.add(mediaInfo);
            }

            cursor.close();
        }
    }

    public static List<MediaInfo> getList() {
        if (list != null) return list;
        else
            return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mediaPlayer != null) {
            mediaPlayer.stop();

            mediaPlayer.release();
        }
    }

    public static void initMediaPlayer(String uri) {
        try {
            to_play.setText(list.get(location).getName());

            mediaPlayer.reset();

            mediaPlayer.setDataSource(uri);

            mediaPlayer.prepare();

            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static MediaPlayer getMediaPlayer() {
        return mediaPlayer;
    }
}