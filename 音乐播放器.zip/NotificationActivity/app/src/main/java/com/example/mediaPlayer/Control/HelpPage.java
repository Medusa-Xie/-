package com.example.mediaPlayer.Control;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mediaPlayer.R;

public class HelpPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_page);
    }
}
