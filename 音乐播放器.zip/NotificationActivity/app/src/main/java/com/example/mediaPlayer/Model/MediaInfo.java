package com.example.mediaPlayer.Model;

public class MediaInfo {
    private long id;
    private String name;//歌曲名
    private String alubm;//专辑
    private String singer;//歌手
    private String time;//歌曲时间
    private String uri;//歌曲路径

    public MediaInfo(){}

    public MediaInfo(long id, String name, String alubm, String singer, String time, String uri) {
        this.id = id;
        this.name = name;
        this.alubm = alubm;
        this.singer = singer;
        this.time = time;
        this.uri = uri;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAlubm() {
        return alubm;
    }

    public void setAlubm(String alubm) {
        this.alubm = alubm;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }


    public String showInfo() {
        return id + "," + name + "," + singer + "-" + alubm + "," + time + "," + uri;
    }
}
