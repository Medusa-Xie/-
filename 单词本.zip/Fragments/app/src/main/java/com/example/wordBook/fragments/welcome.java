package com.example.wordBook.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.example.wordBook.R;

public class welcome extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceSata) {
        View view = inflater.inflate(R.layout.start_view, container, false);

        return view;
    }
}
