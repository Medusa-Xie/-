package com.example.wordBook.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

import com.example.wordBook.Control.addWords;
import com.example.wordBook.Control.updateWords;
import com.example.wordBook.R;

public class meFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceSata) {
        View view = inflater.inflate(R.layout.me_fragment, container, false);

        Button add = (Button) view.findViewById(R.id.add_words);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), addWords.class);

                startActivity(intent);
            }
        });

        Button update = (Button) view.findViewById(R.id.update_words);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), updateWords.class);

                startActivity(intent);
            }
        });

        return view;
    }
}
