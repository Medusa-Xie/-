package com.example.wordBook.Model;

/**
 * 单词类
 */
public class words {
    private String Name = "";//名称

    private String usa_soundmark = "";//美音音标
    private String eng_soundmark = "";//英音音标

    private String n_property = "";//名词词性的解释
    private String adj_property = "";//形容词词性的解释
    private String v_property = "";//动词词性的解释
    private String adv_property = "";//副词词性的解释

    private String sentence_1 = "";//造句1
    private String sentence_2 = "";//造句2
    private String sentence_3 = "";//造句3

    public words() {}

    public words(String Name) {
        this.Name = Name;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getUsa_soundmark() {
        return usa_soundmark;
    }

    public void setUsa_soundmark(String usa_soundmark) {
        this.usa_soundmark = "美式发音：" + usa_soundmark;
    }

    public String getEng_soundmark() {
        return eng_soundmark;
    }

    public void setEng_soundmark(String eng_soundmark) {
        this.eng_soundmark = "英式发音：" + eng_soundmark;
    }

    public String getN_property() {
        return n_property;
    }

    public void setN_property(String n_property) {
        this.n_property = "n." + n_property;
    }

    public String getAdj_property() {
        return adj_property;
    }

    public void setAdj_property(String adj_property) {
        this.adj_property = "adj." + adj_property;
    }

    public String getV_property() {
        return v_property;
    }

    public void setV_property(String v_property) {
        this.v_property = "v." + v_property;
    }

    public String getAdv_property() {
        return adv_property;
    }

    public void setAdv_property(String adv_property) {
        this.adv_property = "adv." + adv_property;
    }

    public String getSentence_1() {
        return sentence_1;
    }

    public void setSentence_1(String sentence_1) {
        this.sentence_1 = "例句1：" + sentence_1;
    }

    public String getSentence_2() {
        return sentence_2;
    }

    public void setSentence_2(String sentence_2) {
        this.sentence_2 = "例句2：" + sentence_2;
    }

    public String getSentence_3() {
        return sentence_3;
    }

    public void setSentence_3(String sentence_3) {
        this.sentence_3 = "例句3：" + sentence_3;
    }

    public String getProperties() {
        String result = "";

        if (!getN_property().equals("n.null")) result += getN_property() + " ";

        if (!getAdv_property().equals("adv.null")) result += getAdv_property() + " ";

        if (!getAdj_property().equals("adj.null")) result += getAdj_property() + " ";

        if (!getV_property().equals("v.null")) result += getV_property() + " ";

        return result;
    }

    public String review_getProperties() {
        return getN_property() + '\n' + getAdj_property() + '\n' + getAdv_property() + '\n' + getV_property();
    }
}
