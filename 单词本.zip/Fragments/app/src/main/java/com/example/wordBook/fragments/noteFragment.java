package com.example.wordBook.fragments;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.example.wordBook.Control.reviewPage;
import com.example.wordBook.Model.KMP;
import com.example.wordBook.Model.words;
import com.example.wordBook.R;

import java.util.ArrayList;
import java.util.List;

public class noteFragment extends Fragment {
    ArrayAdapter<String> adapter;

    public static List<String> list = new ArrayList<>();//ListView列表
    public static List<com.example.wordBook.Model.words> Words_list = new ArrayList<>();//单词列表（主要用于review）

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.notes_fragment, container, false);

        updateData();

        final ListView listView = (ListView) view.findViewById(R.id.record_words);

        adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, list);

        listView.setAdapter(adapter);

        Button review = (Button) view.findViewById(R.id.review);
        review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!list.isEmpty()) {
                    Intent intent = new Intent(getActivity(), reviewPage.class);

                    startActivity(intent);
                }
            }
        });

        return view;
    }

    private void updateData() {
        list.clear();
        Words_list.clear();
        /*
        初始化：先清空单词列表，防止刷出重复的单词
         */

        Uri uri = Uri.parse("content://com.example.databasetest.provider/words");

        Cursor cursor = getContext().getContentResolver().query(uri, null,
                "isUnfamiliar = ?", new String[]{"1"}, null);
        /*
        获取数据库中记录的全部数据
         */

        if (cursor != null) {
            while (cursor.moveToNext()) {
                words word = new words();

                String word_name = cursor.getString(cursor.getColumnIndex("word_name"));
                word.setName(word_name);

                String word_usa_soundmark = cursor.getString(cursor.getColumnIndex("word_usa_soundmark"));
                if (word_usa_soundmark != null) word.setUsa_soundmark(word_usa_soundmark.substring(4));

                String word_eng_soundmark = cursor.getString(cursor.getColumnIndex("word_eng_soundmark"));
                if (word_eng_soundmark != null) word.setEng_soundmark(word_eng_soundmark.substring(4));

                String n_property = cursor.getString(cursor.getColumnIndex("n_property"));
                if (n_property != null) word.setN_property(n_property.substring(2));

                String adj_property = cursor.getString(cursor.getColumnIndex("adj_property"));
                if (adj_property != null) word.setAdj_property(adj_property.substring(4));

                String adv_property = cursor.getString(cursor.getColumnIndex("adv_property"));
                if (adv_property != null) word.setAdv_property(adv_property.substring(4));

                String v_property = cursor.getString(cursor.getColumnIndex("v_property"));
                if (v_property != null) word.setV_property(v_property.substring(2));

                String sentence_hint = cursor.getString(cursor.getColumnIndex("sentence_1"));

                int block = new KMP(word_name).search(sentence_hint.substring(4));

                String underline = "";
                for (int i = 0; i < word_name.length(); i++) underline += "_";

                sentence_hint = sentence_hint.substring(0, block + 4) + underline +
                        sentence_hint.substring(block + 4 + word_name.length());

                word.setSentence_1("例句：" + sentence_hint.substring(4));
                /*
                提示用户
                 */

                Words_list.add(word);
                list.add(word_name);
            }

            cursor.close();
        }
    }

    public static List getWord_List() {
        return Words_list;
    }
}
