package com.example.wordBook.fragments;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.wordBook.R;

public class wordLandFragment extends Fragment {
    private static String word_name;

    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.word_land_page, container, false);

        Uri uri = Uri.parse("content://com.example.databasetest.provider/words");

        Cursor cursor = getActivity().getContentResolver().query(uri, null, "word_name = ?",
                new String[]{word_name}, null);

        TextView name = (TextView) view.findViewById(R.id.word_name);

        TextView usa_soundmark = (TextView) view.findViewById(R.id.word_usa_soundmark);

        TextView eng_soundmark = (TextView) view.findViewById(R.id.word_eng_soundmark);

        TextView n_property = (TextView) view.findViewById(R.id.word_n_property);

        TextView adj_property = (TextView) view.findViewById(R.id.word_adj_property);

        TextView adv_property = (TextView) view.findViewById(R.id.word_adv_property);

        TextView v_property = (TextView) view.findViewById(R.id.word_v_property);

        TextView sentence_1 = (TextView) view.findViewById(R.id.word_sentence_1);

        TextView sentence_2 = (TextView) view.findViewById(R.id.word_sentence_2);

        TextView sentence_3 = (TextView) view.findViewById(R.id.word_sentence_3);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                name.setText(word_name);

                String usa = cursor.getString(cursor.getColumnIndex("word_usa_soundmark"));
                setText(usa_soundmark, usa);

                String eng = cursor.getString(cursor.getColumnIndex("word_eng_soundmark"));
                setText(eng_soundmark, eng);

                String adj = cursor.getString(cursor.getColumnIndex("adj_property"));
                setText(adj_property, adj);

                String adv = cursor.getString(cursor.getColumnIndex("adv_property"));
                setText(adv_property, adv);

                String n = cursor.getString(cursor.getColumnIndex("n_property"));
                setText(n_property, n);

                String v = cursor.getString(cursor.getColumnIndex("v_property"));
                setText(v_property, v);

                String s1 = cursor.getString(cursor.getColumnIndex("sentence_1"));
                setText(sentence_1, s1);

                String s2 = cursor.getString(cursor.getColumnIndex("sentence_2"));
                setText(sentence_2, s2);

                String s3 = cursor.getString(cursor.getColumnIndex("sentence_3"));
                setText(sentence_3, s3);
            }

            cursor.close();
        }

        Button button = (Button) view.findViewById(R.id.remember);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "clicked", Toast.LENGTH_SHORT).show();
            }
        });

        Button notRemember = (Button) view.findViewById(R.id.dontRemember);
        notRemember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("content://com.example.databasetest.provider/words");
                /*
                通过databasetest项目的内容提供器contentProvider，连接到了databasetest项目的数据库myWords的表words中
                之后的所有关于数据库的操作，将会体现在databasetest项目的数据库myWords中
                 */

                ContentValues values = new ContentValues();

                values.put("isUnfamiliar", 1);

                getActivity().getContentResolver().update(uri, values, "word_name = ?",
                        new String[]{word_name});//将单词插入到数据库中

                Toast.makeText(getContext(), "单词已记录到生词本中", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    private void setText(final TextView textView, String txt) {
        if (txt == null) textView.setVisibility(View.GONE);
        else
            textView.setText(txt);
    }

    public static void setWordName(String string) {
        word_name = string;
    }
}
