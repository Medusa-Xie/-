package com.example.wordBook;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class help extends AppCompatActivity {
    private String HELP = "进入主界面后，您会看到List、News、Note、Me四个导航键" + '\n' +
            "1.List按钮：进入单词本页面，在这里您可以通过点击您感兴趣的单词查看单词释义、发音、例句等详细单词信息，通过点击‘认识’" + '\n' +
            "或‘不认识’按钮，可以选择是否将该单词计入到您的生词本中。" + '\n' +
            "2.News按钮：进入新闻页面，在这里您将会进入环球新闻网站进行浏览。" + '\n' +
            "3.Note按钮：进入您的专属生词本页面，在这里记录着您生疏的单词，您可以在该页面中进行全部生词的复习。通过您的复习，" + '\n' +
            "您认识的单词将会从生词本中抹去。" + '\n' +
            "4.Me按钮：进入您的用户界面，在这里您可以添加单词或者修改一个单词。";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        TextView textView = (TextView) findViewById(R.id.help_document);
        textView.setText(HELP);
    }
}
