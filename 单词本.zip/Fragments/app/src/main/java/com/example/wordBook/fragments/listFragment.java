package com.example.wordBook.fragments;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.wordBook.Control.MainActivity;
import com.example.wordBook.Control.searchPage;
import com.example.wordBook.Control.wordPage;
import com.example.wordBook.Model.words;
import com.example.wordBook.R;

import java.util.ArrayList;
import java.util.List;

public class listFragment extends Fragment {
    private static final String TAG = "listFragment";

    private List<words> wordsList = new ArrayList<>();//单词列表
    public static String clicked_word;//点击的单词名称

    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.list_fragment, container, false);

        Log.i(TAG, "onCreateView: " + MainActivity.test);

        initWords();//初始化ListView

        ListView listView = (ListView) view.findViewById(R.id.words_list);

        wordsAdapter adapter = new wordsAdapter(getContext(), R.layout.word_item, wordsList);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (MainActivity.ori == MainActivity.mConfiguration.ORIENTATION_PORTRAIT) {
                    Intent intent = new Intent(getContext(), wordPage.class);

                    words word = wordsList.get(i);

                    intent.putExtra("clickedWord_name", word.getName());

                    startActivity(intent);
                } else {
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

                    fragmentTransaction.replace(R.id.list_land_framelayout, new wordLandFragment());

                    fragmentTransaction.commit();

                    clicked_word = wordsList.get(i).getName();//获取单词拼写

                    wordLandFragment.setWordName(clicked_word);
                }
            }
        });

        Button search = (Button) view.findViewById(R.id.search_words);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), searchPage.class);

                startActivity(intent);
            }
        });

        return view;
    }

    /**
     * 从数据库中获取单词，初始化单词列表
     */
    public void initWords() {
        //通过URI获取对应文件
        Uri uri = Uri.parse("content://com.example.databasetest.provider/words");

        Cursor cursor = getContext().getContentResolver().query(uri, null, null,
                null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                words word = new words();

                word.setName(cursor.getString(cursor.getColumnIndex("word_name")));

                word.setUsa_soundmark(cursor.getString(cursor.getColumnIndex("word_usa_soundmark")));

                word.setEng_soundmark(cursor.getString(cursor.getColumnIndex("word_eng_soundmark")));

                String n_property = cursor.getString(cursor.getColumnIndex("n_property"));
                if (n_property != null) word.setN_property(n_property.substring(2));

                String adj_property = cursor.getString(cursor.getColumnIndex("adj_property"));
                if (adj_property != null) word.setAdj_property(adj_property.substring(4));

                String adv_property = cursor.getString(cursor.getColumnIndex("adv_property"));
                if (adv_property != null) word.setAdv_property(adv_property.substring(4));

                String v_property = cursor.getString(cursor.getColumnIndex("v_property"));
                if (v_property != null) word.setV_property(v_property.substring(2));

                word.setSentence_1(cursor.getString(cursor.getColumnIndex("sentence_1")));

                word.setSentence_2(cursor.getString(cursor.getColumnIndex("sentence_2")));

                word.setSentence_3(cursor.getString(cursor.getColumnIndex("sentence_3")));

                wordsList.add(word);
            }

            cursor.close();
        }
    }

    /**
     * ListView适配器
     */
    class wordsAdapter extends ArrayAdapter<words> {
        private int resourceId;

        /**
         * 提升ListView效率的ViewHolder，用于保存ListView中所有的控件
         */
        class ViewHolder {
            TextView textView_name;
            TextView textView_explaination;
        }

        public wordsAdapter(Context context, int textViewResourceId, List<words> objects) {
            super(context, textViewResourceId, objects);

            resourceId = textViewResourceId;
        }

        /**
         * 滚动listview时调用的更新视图的方法
         * @param position 新刷新出来的listview中某一项的位置
         * @param converView 缓存视图（可以将其进行重用从而改进效率）
         * @param parent 布局容器，可用来存放多个View和ViewGroup
         * @return
         */
        @Override
        public View getView(int position, View converView, ViewGroup parent) {
            words word = getItem(position);
            View view;
            ViewHolder viewHolder;

            if (converView == null) {
                view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);

                viewHolder = new ViewHolder();

                viewHolder.textView_name = (TextView) view.findViewById(R.id.word);
                viewHolder.textView_explaination = (TextView) view.findViewById(R.id.explaination);

                view.setTag(viewHolder);
            } else {
                view = converView;

                viewHolder = (ViewHolder) view.getTag();
            }

            viewHolder.textView_name.setText(word.getName());
            viewHolder.textView_explaination.setText(word.getProperties());

            return view;
        }
    }
}
