package com.example.wordBook.Control;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.wordBook.R;

public class updateWords extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_words);

        Button entering = (Button) findViewById(R.id.update_entering);
        entering.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText word_name = (EditText) findViewById(R.id.update_words_name);
                String new_word_name = word_name.getText().toString();

                EditText word_usa = (EditText) findViewById(R.id.update_words_usa_soundmark);
                String new_word_usa = word_usa.getText().toString();

                EditText word_eng = (EditText) findViewById(R.id.update_words_eng_soundmark);
                String new_word_eng = word_eng.getText().toString();

                EditText word_N = (EditText) findViewById(R.id.update_words_n_propertty);
                String new_word_N = word_N.getText().toString();

                EditText word_Adj = (EditText) findViewById(R.id.update_words_adj_property);
                String new_word_adj = word_Adj.getText().toString();

                EditText word_adv = (EditText) findViewById(R.id.update_words_adv_property);
                String new_word_adv = word_adv.getText().toString();

                EditText word_V = (EditText) findViewById(R.id.update_words_v_property);
                String new_word_V = word_V.getText().toString();

                EditText sentence_1 = (EditText) findViewById(R.id.update_words_sentence_1);
                String new_word_s1 = sentence_1.getText().toString();

                EditText sentence_2 = (EditText) findViewById(R.id.update_words_sentence_2);
                String new_word_s2 = sentence_2.getText().toString();

                EditText sentence_3 = (EditText) findViewById(R.id.update_words_sentence_3);
                String new_word_s3 = sentence_3.getText().toString();

                Uri uri = Uri.parse("content://com.example.databasetest.provider/words");

                ContentValues values = new ContentValues();

//                values.put("word_name", new_word_name);
                if (!new_word_usa.isEmpty()) values.put("word_usa_soundmark", "美式发音" + new_word_usa);
                if (!new_word_eng.isEmpty()) values.put("word_eng_soundmark", "英式发音" + new_word_eng);
                if (!new_word_N.isEmpty()) values.put("n_property", "n." + new_word_N);
                if (!new_word_adj.isEmpty()) values.put("adj_property", "adj." + new_word_adj);
                if (!new_word_adv.isEmpty()) values.put("adv_property", "adv." + new_word_adv);
                if (!new_word_V.isEmpty()) values.put("v_property", "v." + new_word_V);
                if (!new_word_s1.isEmpty()) values.put("sentence_1", "例句1:" + new_word_s1);
                if (!new_word_s2.isEmpty()) values.put("sentence_2", "例句2:" + new_word_s2);
                if (!new_word_s3.isEmpty()) values.put("sentence_3", "例句3:" + new_word_s3);

                int updateRows = getContentResolver().update(uri, values, "word_name = ?",
                        new String[]{new_word_name});

                AlertDialog.Builder dialog = new AlertDialog.Builder(updateWords.this);

                if (updateRows != 0) {
                    dialog.setTitle("修改成功！");
                    dialog.setMessage("单词已成功修改");
                    dialog.setCancelable(false);
                    dialog.setPositiveButton("我知道了", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    });

                    dialog.show();
                } else {
                    dialog.setTitle("修改失败");
                    dialog.setMessage("单词未成功修改");
                    dialog.setCancelable(false);
                    dialog.setPositiveButton("我知道了", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    });

                    dialog.show();
                }
            }
        });

        Button exit = (Button) findViewById(R.id.update_exit);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}

