package com.example.wordBook.Control;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.wordBook.R;
import com.example.wordBook.fragments.listFragment;
import com.example.wordBook.fragments.listLandFragment;
import com.example.wordBook.fragments.meFragment;
import com.example.wordBook.fragments.newsFragment;
import com.example.wordBook.fragments.noteFragment;
import com.example.wordBook.fragments.welcome;
import com.example.wordBook.help;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    public static int ori;
    public static Configuration mConfiguration;

    public static String test = "测试！";

    private class myLayoutListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.wordsList:
                    changeFragment(new listFragment());

                    break;
                case R.id.EnglishNews:
                    changeFragment(new newsFragment());

                    break;
                case R.id.Notes:
                    changeFragment(new noteFragment());

                    break;
                case R.id.Me:
                    changeFragment(new meFragment());

                    break;
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mConfiguration = this.getResources().getConfiguration(); //获取设置的配置信息
        ori = mConfiguration.orientation; //获取屏幕方向

        if (ori == mConfiguration.ORIENTATION_PORTRAIT) {
            changeFragment(new welcome());

            Button buttonList = (Button) findViewById(R.id.wordsList);
            buttonList.setOnClickListener(new myLayoutListener());
        } else {
            Button buttonList = (Button) findViewById(R.id.wordsList);
            buttonList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    changeFragment(new listLandFragment());
                }
            });
        }

        Button buttonNews = (Button) findViewById(R.id.EnglishNews);
        buttonNews.setOnClickListener(new myLayoutListener());

        Button buttonNotes = (Button) findViewById(R.id.Notes);
        buttonNotes.setOnClickListener(new myLayoutListener());

        Button buttonMe = (Button) findViewById(R.id.Me);
        buttonMe.setOnClickListener(new myLayoutListener());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.help:
                Intent intentT = new Intent(MainActivity.this, help.class);

                startActivity(intentT);

                break;

            case R.id.exit:
                finish();

                break;
        }

        return true;
    }

    public void changeFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        fragmentTransaction.replace(R.id.frameLayout, fragment);

        fragmentTransaction.commit();
    }
}
