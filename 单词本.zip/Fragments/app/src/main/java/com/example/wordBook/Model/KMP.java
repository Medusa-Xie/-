package com.example.wordBook.Model;

public class KMP {
    private String pat;
    private int[][] dfa;

    public KMP(String pat) {
        int R = 256;
        this.pat = pat;
        dfa = new int[R][pat.length()];

        dfa[pat.charAt(0)][0] = 1;//初始化第一列

        for (int X = 0, j = 1; j < pat.length(); j++) {
            for (int c = 0; c < R; c++)
                dfa[c][j] = dfa[c][X];//相同的重启状态下，对应dfa的列是相同的

            dfa[pat.charAt(j)][j] = j + 1;//与模式的第j个字符相匹配的时候，即可开始检查文本和模式对应的下一个字符

            X = dfa[pat.charAt(j)][X];
            //重启状态的更新：当模式字符串j位置的字符查找正确后，如果j+1位置字符查找出现错误，需要重新遍历查找的位置（列）
        }
    }
    /*
    构建dfa查找数组，在其中有一点动态规划的思想
     */

    public int search(String txt) {
        int i;//txt指针
        int j;//模式指针
        int N = txt.length();
        int M = pat.length();

        for (i = 0, j = 0; i < N && j < M; i++)
            j = dfa[txt.charAt(i)][j];

        if (j == M) return i - M;//找到匹配
        else
            return N;//未找到匹配
    }
    /*
    在KMP方法中，文本txt的指针i不会回退；模式指针j可以回退，因此可以保证KMP在最坏情况下的时间复杂度为M+N
     */
}
