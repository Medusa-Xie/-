package com.example.wordBook.Control;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.example.wordBook.R;

import java.util.ArrayList;
import java.util.List;

public class searchPage extends AppCompatActivity {
    private static final String DATA_BASE = "content://com.example.databasetest.provider/words";
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);

        final List<String> matchWords = new ArrayList<>();//匹配单词列表

        final EditText editText = (EditText) findViewById(R.id.what_words);
        editText.setFocusable(true);
        editText.setFocusableInTouchMode(true);
        editText.requestFocus();
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                matchWords.clear();

                Uri uri = Uri.parse(DATA_BASE);

                Cursor cursor = getContentResolver().query(uri, new String[]{"word_name"},
                        "word_name LIKE ?", new String[]{"%" + editable + "%"}, null);

                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        matchWords.add(cursor.getString(cursor.getColumnIndex("word_name")));

                        adapter.notifyDataSetChanged();
                    }
                }

                cursor.close();
            }
        });
        /*
        设置edittext自动弹出软键盘并进行模糊查询
         */

        ListView listView = (ListView) findViewById(R.id.search_result);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(searchPage.this, wordPage.class);

                intent.putExtra("clickedWord_name", matchWords.get(i));

                startActivity(intent);

                finish();
            }
        });

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, matchWords);

        listView.setAdapter(adapter);
    }
}
