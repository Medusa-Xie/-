package com.example.wordBook.Control;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.wordBook.Model.KMP;
import com.example.wordBook.R;

public class addWords extends AppCompatActivity {
    private boolean hasMistakes = false;//判断例句中是否存在错误
    private Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_words);

        Button entering = (Button) findViewById(R.id.entering);
        entering.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hasMistakes = false;

                EditText word_name = (EditText) findViewById(R.id.add_words_name);
                String new_word_name = word_name.getText().toString();

                EditText word_usa = (EditText) findViewById(R.id.add_words_usa_soundmark);
                String new_word_usa = word_usa.getText().toString();

                EditText word_eng = (EditText) findViewById(R.id.add_words_eng_soundmark);
                String new_word_eng = word_eng.getText().toString();

                EditText word_N = (EditText) findViewById(R.id.add_words_n_propertty);
                String new_word_N = word_N.getText().toString();

                EditText word_Adj = (EditText) findViewById(R.id.add_words_adj_property);
                String new_word_adj = word_Adj.getText().toString();

                EditText word_adv = (EditText) findViewById(R.id.add_words_adv_property);
                String new_word_adv = word_adv.getText().toString();

                EditText word_V = (EditText) findViewById(R.id.add_words_v_property);
                String new_word_V = word_V.getText().toString();

                EditText sentence_1 = (EditText) findViewById(R.id.add_words_sentence_1);
                String new_word_s1 = sentence_1.getText().toString();

                EditText sentence_2 = (EditText) findViewById(R.id.add_words_sentence_2);
                String new_word_s2 = sentence_2.getText().toString();

                EditText sentence_3 = (EditText) findViewById(R.id.add_words_sentence_3);
                String new_word_s3 = sentence_3.getText().toString();

                uri = Uri.parse("content://com.example.databasetest.provider/words");

                ContentValues values = new ContentValues();

                values.put("word_name", new_word_name);
                if (!new_word_usa.isEmpty())
                    values.put("word_usa_soundmark", "美式发音" + new_word_usa);

                if (!new_word_eng.isEmpty())
                    values.put("word_eng_soundmark", "英式发音" + new_word_eng);

                if (!new_word_N.isEmpty()) values.put("n_property", "n." + new_word_N);

                if (!new_word_adj.isEmpty()) values.put("adj_property", "adj." + new_word_adj);

                if (!new_word_adv.isEmpty()) values.put("adv_property", "adv." + new_word_adv);

                if (!new_word_V.isEmpty()) values.put("v_property", "v." + new_word_V);

                if (!new_word_s1.isEmpty()) {
                    if (new KMP(new_word_name).search(new_word_s1) == new_word_s1.length()) hasMistakes = true;
                    else {
                        values.put("sentence_1", "例句1：" + new_word_s1);
                    }
                }

                if (!new_word_s2.isEmpty()) {
                    if (new KMP(new_word_name).search(new_word_s2) == new_word_s2.length()) hasMistakes = true;
                    else {
                        values.put("sentence_2", "例句2：" + new_word_s2);
                    }
                }

                if (!new_word_s3.isEmpty()) {
                    if (new KMP(new_word_name).search(new_word_s3) == new_word_s3.length()) hasMistakes = true;
                    else {
                        values.put("sentence_3", "例句3：" + new_word_s3);
                    }
                }

                values.put("isUnfamiliar", 0);

                if (!hasMistakes) {
                    getContentResolver().insert(uri, values);

                    showDialog("单词已录入成功");
                } else {
                    showDialog("错误：例句中未检测到目标单词");
                }
            }
        });

        Button exit = (Button) findViewById(R.id.exit);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void showDialog(String txt) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(addWords.this);

        dialog.setTitle("录入情况");
        dialog.setMessage(txt);
        dialog.setCancelable(false);
        dialog.setPositiveButton("我知道了", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (!hasMistakes) finish();
                else
                    hasMistakes = false;//重置
            }
        });

        dialog.show();
    }
}
