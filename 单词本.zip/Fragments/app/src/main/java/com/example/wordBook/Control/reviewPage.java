package com.example.wordBook.Control;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wordBook.R;

import java.util.ArrayList;
import java.util.List;

public class reviewPage extends AppCompatActivity {
    List<com.example.wordBook.Model.words> list = new ArrayList<>();
    int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_page);

        final TextView name = (TextView) findViewById(R.id.review_word_name);
        final TextView usa_soundmark = (TextView) findViewById(R.id.review_usa_soundmark);
        final TextView eng_soundmark = (TextView) findViewById(R.id.review_eng_soundmark);
        final TextView hint = (TextView) findViewById(R.id.review_word_hint);
        final TextView explaination = (TextView) findViewById(R.id.review_word_explaination);

        this.list = com.example.wordBook.fragments.noteFragment.getWord_List();//获取note中的单词列表

        name.setText(list.get(i).getName());//初始化
        usa_soundmark.setText(list.get(i).getUsa_soundmark());
        eng_soundmark.setText(list.get(i).getEng_soundmark());
        hint.setText(list.get(i).getSentence_1());

        Button show = (Button) findViewById(R.id.show_explaination);
        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                explaination.setText(list.get(i).review_getProperties());
            }
        });

        Button r_rem = (Button) findViewById(R.id.review_remember);
        r_rem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("content://com.example.databasetest.provider/words");

                ContentValues values = new ContentValues();

                values.put("isUnfamiliar", 0);

                getContentResolver().update(uri, values, "word_name = ?", new String[]{name.getText().toString()});

                if (i + 1 < list.size()) {
                    name.setText(list.get(++i).getName());

                    clearTextView(explaination);
                } else {
                    Toast.makeText(reviewPage.this, "您已经全部复习完成", Toast.LENGTH_SHORT).show();

                    finish();
                }
            }
        });

        Button r_dontRem = (Button) findViewById(R.id.review_dontRemember);
        r_dontRem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (i + 1 < list.size()) {
                    name.setText(list.get(++i).getName());

                    clearTextView(explaination);
                }
                else {
                    Toast.makeText(reviewPage.this, "您已经全部复习完成", Toast.LENGTH_SHORT).show();

                    finish();
                }
            }
        });
    }

    public void clearTextView(final TextView explaination) {
        explaination.setText("");
    }
}
