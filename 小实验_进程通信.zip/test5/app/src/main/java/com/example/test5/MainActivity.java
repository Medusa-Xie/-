package com.example.test5;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Handler handler;
    private TextView show;

    private final static int RECEIVE_MESSAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        show = findViewById(R.id.show);

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {
                switch (msg.what) {
                    case RECEIVE_MESSAGE:
                        show.setText("接收到消息");
                        break;

                    default:
                        break;
                }
                return true;
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    /*延迟3秒发送消息*/
                    Message message = new Message();
                    message.what = RECEIVE_MESSAGE;
                    handler.sendMessageDelayed(message, 3000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
