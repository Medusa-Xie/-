package com.example.wordBook_database;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

public class DatabaseProvider extends ContentProvider {
    public static final int WORD_DIR = 0;
    public static final int WORD_ITEM = 1;

    public static final String AUTHORITY = "com.example.databasetest.provider";//官方

    private static UriMatcher uriMatcher;
    private MyDatabaseHelper helper;

    /*其中uri用于指定哪一个数据源，当一个数据源含有多个内容（比如多个表），就需要用不同的Uri进行区分*/
    static {
        //常量UriMatcher.NO_MATCH表示不匹配任何路径的返回码
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

        //如果match()方法匹配content://com.example.databasetest.provider/words路径，返回匹配码为WORD_DIR
        //如果match()方法匹配content://com.example.databasetest.provider/words/#路径，返回匹配码为WORD_ITEM
        uriMatcher.addURI(AUTHORITY, "words", WORD_DIR);
        uriMatcher.addURI(AUTHORITY, "words/#", WORD_ITEM);
    }

    public DatabaseProvider() {}

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        SQLiteDatabase db = helper.getWritableDatabase();

        int deleteRows = 0;

        switch (uriMatcher.match(uri)) {
            case WORD_DIR:
                deleteRows = db.delete("words", selection, selectionArgs);

                break;
            case WORD_ITEM:
                String wordId = uri.getPathSegments().get(1);

                deleteRows = db.delete("words", "id = ?", new String[]{wordId});

                break;
            default:
        }

        return deleteRows;
    }

    @Override
    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)) {
            case WORD_DIR:
                return "vnd.android.cursor.dir/vnd.com.example.databasetest.provider.words";
            case WORD_ITEM:
                return "vnd.android.cursor.item/vnd.com.example.databasetest.provider.words";
        }

        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        SQLiteDatabase db = helper.getWritableDatabase();

        Uri uriReturn = null;

        switch (uriMatcher.match(uri)) {
            case WORD_DIR:
            case WORD_ITEM:
                long newWordId = db.insert("words", null, values);

                uriReturn = Uri.parse("content://" + AUTHORITY + "/words/" + newWordId);

                break;
            default:
        }

        return uriReturn;
    }

    @Override
    public boolean onCreate() {
        helper = new MyDatabaseHelper(getContext(), "myWords.db", null, 1);

        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        SQLiteDatabase db = helper.getReadableDatabase();

        Cursor cursor = null;

        switch (uriMatcher.match(uri)) {
            case WORD_DIR:
                cursor = db.query("words", projection, selection, selectionArgs,
                        null, null, sortOrder);

                break;
            case WORD_ITEM:
                String wordId = uri.getPathSegments().get(1);//想要获取特定id的表中数据
                cursor = db.query("words", projection, "id = ?", new String[]{wordId},
                        null, null, sortOrder);

                break;
            default:
        }

        return cursor;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        SQLiteDatabase db = helper.getWritableDatabase();

        int updateRows = 0;

        switch (uriMatcher.match(uri)) {
            case WORD_DIR:
                updateRows = db.update("words", values, selection, selectionArgs);

                break;
            case WORD_ITEM:
                String wordId = uri.getPathSegments().get(1);

                updateRows = db.update("words", values, "id = ?", new String[]{wordId});

                break;
            default:
        }

        return updateRows;
    }
}
