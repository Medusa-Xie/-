package com.example.wordBook_database;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.facebook.stetho.Stetho;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private MyDatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Stetho.initializeWithDefaults(this);//Chrome上查看数据库插件

        databaseHelper = new MyDatabaseHelper(this, "myWords.db", null, 1);

        final Button createDB = (Button) findViewById(R.id.createDB);
        createDB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseHelper.getWritableDatabase();
            }
        });

        Button insert = (Button) findViewById(R.id.insertToDB);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = databaseHelper.getWritableDatabase();//获取SQLite数据库对象

                ContentValues contentValues = new ContentValues();

                contentValues.put("word_name", "fuck");

                db.insert("words", null, contentValues);//插入第一条数据

                contentValues.clear();

                contentValues.put("word_name", "fuck");

                db.insert("words", null, contentValues);//插入第二条数据
            }
        });
//
//        Button update = (Button) findViewById(R.id.updateToDB);
//        update.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                SQLiteDatabase db = databaseHelper.getWritableDatabase();
//
//                ContentValues contentValues = new ContentValues();
//
//                contentValues.put("price", 0);
//
//                db.update("Book", contentValues, "name = ?", new String[]{"First Time"});
//                /*
//                更新数据库中的数据，表示将所有name=“First Time”的记录的价格全部修改为0(?是一个占位符)
//                 */
//            }
//        });
//
//        Button del = (Button) findViewById(R.id.delete);
//        del.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                SQLiteDatabase db = databaseHelper.getWritableDatabase();
//
//                db.delete("Book", "pages > ?", new String[]{"450"});
//            }
//        });
//
//        Button query = (Button) findViewById(R.id.query);
//        query.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                SQLiteDatabase db = databaseHelper.getWritableDatabase();
//
//                Cursor cursor = db.query("Book", null, null, null, null, null, null);
//
//                if (cursor.moveToFirst()) {
//                    do {
//                        String name = cursor.getString(cursor.getColumnIndex("name"));
//                        String author = cursor.getString(cursor.getColumnIndex("author"));
//                        int pages = cursor.getInt(cursor.getColumnIndex("pages"));
//                        double price = cursor.getDouble(cursor.getColumnIndex("price"));
//
//                        Log.d("MainActivity", name);
//                        Log.d("MainActivity", author);
//                        Log.d("MainActivity", pages + "");
//                        Log.d("MainActivity", price + "");
//                    }while (cursor.moveToNext());
//
//                    cursor.close();
//                }
//            }
//        });
    }
}
