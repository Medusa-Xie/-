package com.example.wordBook_database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    public static final String CREATE_WORDS = "create table words(" +
            "id integer primary key autoincrement, " +
            "word_name text unique, " +
            "word_usa_soundmark text, " +
            "word_eng_soundmark text, " +
            "n_property text," +
            "adj_property text, " +
            "adv_property text, " +
            "v_property text, " +
            "sentence_1 text, " +
            "sentence_2 text, " +
            "sentence_3 text, " +
            "isUnfamiliar integer)";

    private Context context;

    public MyDatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);

        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_WORDS);//创建单词表
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists words");

        onCreate(db);
    }
}
