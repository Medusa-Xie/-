package com.example.test2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button gotoSecond;
    private TextView whatFromSecond;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();

        whatFromSecond = findViewById(R.id.fromSecond);
        whatFromSecond.setText(intent.getStringExtra("flushToMain"));

        gotoSecond = findViewById(R.id.move);
        gotoSecond.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, secondActivity.class);
                intent.putExtra("flushToSec", "我来到了第二个活动");
                startActivity(intent);
            }
        });
    }
}
