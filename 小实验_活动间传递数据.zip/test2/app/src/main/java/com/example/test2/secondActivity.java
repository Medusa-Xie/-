package com.example.test2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class secondActivity extends AppCompatActivity {
    private Button gotoFirst;
    private TextView whatFromMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();

        whatFromMain = findViewById(R.id.fromMain);
        whatFromMain.setText(intent.getStringExtra("flushToSec"));

        gotoFirst = findViewById(R.id.move);
        gotoFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(secondActivity.this, MainActivity.class);
                intent.putExtra("flushToMain", "我来到了第一个活动");
                startActivity(intent);
            }
        });
    }
}
