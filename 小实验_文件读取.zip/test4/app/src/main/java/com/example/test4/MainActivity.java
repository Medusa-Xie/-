package com.example.test4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    static TextView show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        show = findViewById(R.id.showText);

        final File file = new File(getFilesDir(), "test4");

        Button button = findViewById(R.id.read);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                readFile(file.getAbsolutePath());
            }
        });

        writeFile(file.getAbsolutePath(), "test!!!!!");
    }

    /**
     * 从文件中读取数据库保存的版本号
     *
     * @param fileName 目标文件路径
     */
    public static void readFile(String fileName) {
        File file = new File(fileName);

        InputStream inputStream = null;
        Reader reader = null;
        BufferedReader bufferedReader = null;

        try {
            inputStream = new FileInputStream(file);
            reader = new InputStreamReader(inputStream);
            bufferedReader = new BufferedReader(reader);

            String result = "";

            result = bufferedReader.readLine();

            show.setText(result);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (inputStream != null) inputStream.close();

                if (reader != null) reader.close();

                if (bufferedReader != null) bufferedReader.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 将数据库版本号写入到文件中进行保存
     *
     * @param fileName 目标文件路径
     * @param text     版本号
     */
    public static void writeFile(String fileName, String text) {
        try {
            FileWriter fileWriter = new FileWriter(fileName, false);

            fileWriter.write(text);

            fileWriter.flush();//写入文档中

            fileWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
