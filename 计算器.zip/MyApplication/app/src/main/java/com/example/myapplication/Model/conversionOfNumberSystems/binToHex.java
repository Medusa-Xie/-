package com.example.myapplication.Model.conversionOfNumberSystems;

/**
 * 二进制转换为十六进制
 */
public class binToHex {
    public static String trans(String binNumber) {
        int location = separate(binNumber);
        String binDecimal = "";
        String result = "";

        String binInteger = binNumber.substring(0, location);

        if (location != binNumber.length()) binDecimal = binNumber.substring(location + 1);

        result += binIntergerToHex(binInteger);

        if (binDecimal.length() == 0) return result;

        return result + "." + binDecimalToHex(binDecimal);
    }

    public static int separate(String binNumber) {
        int i;

        for (i = 0; i < binNumber.length(); i++) {
            if (binNumber.charAt(i) == '.') return i;
        }

        return i;
    }

    public static String binDecimalToHex(String decimal) {
        String result = "";
        String nowResult = "";//每四位数字转换为十六进制的结果

        for (int i = 1; i <= decimal.length(); i++) {
            char c = decimal.charAt(i - 1);

            nowResult += c;

            if (i % 4 == 0) {
                result += toHex(nowResult);

                nowResult = "";
            }
        }

        if (decimal.length() % 4 == 0) return result;

        nowResult += "000";

        result += toHex(nowResult);

        return result;
    }

    public static String binIntergerToHex(String integer) {
        String result = "";
        String nowResult = "";//每四位数字转换为十六进制的结果
        int j = 0;

        for (int i = integer.length() - 1; i >= 0; i--) {
            char c = integer.charAt(i);

            nowResult = c + nowResult;

            j++;

            if (j % 4 == 0) {
                result = toHex(nowResult) + result;

                nowResult = "";
            }
        }

        if (integer.length() % 4 == 0) return result;

        if (nowResult.length() == 1) nowResult = "000" + nowResult;
        else if (nowResult.length() == 2) nowResult = "00" + nowResult;
        else
            nowResult = "0" + nowResult;

        result  = toHex(nowResult) + result;

        return result;
    }

    public static String toHex(String binNumber) {
        int result = ((binNumber.charAt(0) - '0') * 8 +
                (binNumber.charAt(1) - '0') * 4 +
                (binNumber.charAt(2) - '0') * 2 +
                (binNumber.charAt(3) - '0') * 1);

        if (result < 10) return result + "";

        switch (result) {
            case 10:
                return "A";
            case 11:
                return "B";
            case 12:
                return "C";
            case 13:
                return "D";
            case 14:
                return "E";
            case 15:
                return "F";
        }

        return null;
    }

    public static void main(String[] args) {
        System.out.println(trans("10111001"));
    }
}
