package com.example.myapplication.Model.conversionOfNumberSystems;

import java.text.DecimalFormat;

/**
 * 将double类型数据由十进制转为二进制
 */
public class decToBin {
    public static String trans(double n) {
        int nInteger = takeIntegerPart(n);
        double nDecimal = takeDecimalPart(n);

        String result = Integer.toBinaryString(nInteger);

        result += DecimaltoBinary(nDecimal);

        return result;
    }

    public static int takeIntegerPart(double n) {
        String target = n + "";
        String result = "";

        for (int i = 0; i < target.length(); i++) {
            char c = target.charAt(i);

            if (c == '.') break;

            result += c;
        }

        return Integer.parseInt(result);
    }

    public static double takeDecimalPart(double n) {
        DecimalFormat df = new DecimalFormat("0.0000000000000000");//限制取小数的位数

        double result = n - (double) takeIntegerPart(n);

        if (result > 0)
            return Double.parseDouble(df.format(result));
        else
            return 0;
    }

    public static String DecimaltoBinary(double n) {
        if (n == 0) return "";

        String result = "";

        for (int i = 0; i < 16; i++) {
            if (n == 0) break;

            n = n * 2;

            result += takeIntegerPart(n);

            n = takeDecimalPart(n);
        }

        return "." + result;
    }

    public static void main(String[] args) {
        System.out.println(trans(12.222));
    }
}
