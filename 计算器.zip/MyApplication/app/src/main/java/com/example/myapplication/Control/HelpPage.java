package com.example.myapplication.Control;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.myapplication.R;

public class HelpPage extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_page);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.help_main, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.helpToCalculatoer :
                Intent intentC = new Intent(HelpPage.this, MainActivity.class);

                startActivity(intentC);

                break;
            case R.id.helpToTransitions:
                Intent intentT = new Intent(HelpPage.this, transitions.class);

                startActivity(intentT);

                break;
        }

        return true;
    }
}
