package com.example.myapplication.Model;

public class ExpressionPosfix {
    /**
     * 传入算式中括号是否匹配
     * @param infix 目标算式
     * @return 是否匹配？
     */
    public static boolean isMatched(String infix){
        SeqStack<String> stack = new SeqStack<String>();

        for(int i = 0; i < infix.length(); i++){
            char x = infix.charAt(i);

            switch (x) {
                case '(':
                    stack.push(x + "");
                    break;
                case ')':
                    if (stack.isEmpty() || !stack.pop().equals("("))
                        return false;
                    break;
            }
        }

        return stack.isEmpty()? true : false;
    }

    /**
     * 将传入的中缀表达式转为后缀表达式
     * @param infix 目标中缀表达式
     * @return 目标中缀表达式的后缀表达式
     */
    public static String toPostfix(String infix) {
        int tfFlag = 0;//0为未输入；1为Sin；2为Cos；3为Tan；4为符号；5为负数；6为正常输入；
        SeqStack<String> stack = new SeqStack<String>();//存储运算符
        String posfix = new String();//存储后缀表达式

        if (infix == null)
            return "请传输算式";

        for (int i = 0; i < infix.length(); i++) {
            char ch = infix.charAt(i);

            switch (ch) {
                case '+':
                case '-':
                    if ((tfFlag == 4 || tfFlag == 0) && ch == '-') {
                        tfFlag = 5;

                        break;
                    }

                    while (!stack.isEmpty() && !stack.peek().equals("("))
                        posfix += stack.pop() + " ";

                    stack.push(ch + "");

                    tfFlag = 4;

                    break;

                case '*':
                case '/':
                    while (!stack.isEmpty() && (stack.peek().equals("*") ||
                            stack.peek().equals("/") || stack.peek().equals("^")))
                        posfix += stack.pop() + " ";

                    stack.push(ch + "");

                    tfFlag = 4;

                    break;

                case '^':
                    stack.push(ch + "");

                    tfFlag = 4;

                    break;

                case '(':
                    stack.push(ch + "");

                    tfFlag = 4;

                    break;

                case ')':
                    String out = stack.pop();

                    while (out != null && !out.equals("(")) {
                        posfix += out + " ";

                        out = stack.pop();
                    }
                    break;

                case 'S':
                case 'C':
                case 'T':
                    if (ch == 'S') tfFlag = 1;
                    else if (ch == 'C') tfFlag = 2;
                    else
                        tfFlag = 3;

                    ch = infix.charAt(i += 2);

                    break;

                default:
                    while ((i < infix.length() && ch >= '0' && ch <= '9') || ch == '.') {
                        posfix += ch;

                        i++;

                        if (i < infix.length())//限制最后一个数字判断不出界
                            ch = infix.charAt(i);
                    }

                    if (tfFlag == 1) posfix += "Sin ";
                    else if (tfFlag == 2) posfix += "Cos ";
                    else if (tfFlag == 3) posfix += "Tan ";
                    else if (tfFlag == 5) posfix += "- ";
                    else
                        posfix += " ";

                    tfFlag = 6;

                    i--;

                    break;
            }
        }

        while (!stack.isEmpty())
            posfix += stack.pop() + " ";

        return posfix;
    }

    /**
     * 计算后缀表达式的值
     * @param posfix 目标后缀表达式
     * @return 目标后缀表达式的计算结果
     */
    public static double Value(String posfix) {
        SeqStack<Double> stack = new SeqStack<Double>();//数字栈

        for (int i = 0; i < posfix.length(); i++) {
            char ch = posfix.charAt(i);

            if (ch >= '0' && ch <= '9') {
                double value = 0;
                int backCount = -1;//小数点回退位数

                while (ch != ' ') {
                    if (ch == '.') {
                        backCount++;

                        ch = posfix.charAt(++i);

                        continue;
                    }

                    value = value * 10 + ch - '0';
                    ch = posfix.charAt(++i);

                    if (backCount > -1) backCount++;

                    if (ch == '-') {
                        value = 0 - value;

                        ch = posfix.charAt(++i);
                    }
                    if (ch == 'S') {
                        value = Math.sin(value);

                        ch = posfix.charAt(i += 3);
                    }
                    if (ch == 'C') {
                        value = Math.cos(value);

                        ch = posfix.charAt(i += 3);
                    }
                    if (ch == 'T') {
                        value = Math.tan(value);

                        ch = posfix.charAt(i += 3);
                    }
                }

                if (backCount > -1) value = value / Math.pow(10, backCount);

                stack.push(value);
            } else {
                if (ch != ' ') {
                    double y = stack.pop();
                    double x = stack.pop();

                    switch (ch) {
                        case '+':
                            stack.push((x + y));
                            break;
                        case '-':
                            stack.push((x - y));
                            break;
                        case '*':
                            stack.push((x * y));
                            break;
                        case '/':
                            stack.push((x / y));
                            break;
                        case '^':
                            stack.push(Math.pow(x, y));
                    }
                }
            }
        }

        return stack.pop();
    }
}

