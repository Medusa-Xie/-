package com.example.myapplication.Control;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.Model.ExpressionPosfix;
import com.example.myapplication.R;

public class MainActivity extends AppCompatActivity {
    private int flag = 0;//当前计算器状态，0为未计算; 1为已计算; 2为输入数字; 3为输入运算符; 4为三角函数
    private int minusCount = 0;//减号计数器

    private class PressNumber implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.ButtonOne:
                    setEditText('1');
                    break;
                case R.id.ButtonTwo:
                    setEditText('2');
                    break;
                case R.id.ButtonThree:
                    setEditText('3');
                    break;
                case R.id.ButtonFour:
                    setEditText('4');
                    break;
                case R.id.ButtonFive:
                    setEditText('5');
                    break;
                case R.id.ButtonSix:
                    setEditText('6');
                    break;
                case R.id.ButtonSeven:
                    setEditText('7');
                    break;
                case R.id.ButtonEight:
                    setEditText('8');
                    break;
                case R.id.ButtonNine:
                    setEditText('9');
                    break;
                case R.id.ButtonZero:
                    setEditText('0');
                    break;
                case R.id.ButtonPlus:
                    setEditText('+');
                    break;
                case R.id.ButtonMinus:
                    setEditText('-');
                    break;
                case R.id.ButtonMultiply:
                    setEditText('*');
                    break;
                case R.id.ButtonDiv:
                    setEditText('/');
                    break;
                case R.id.ButtonPoint:
                    setEditText('.');
                    break;
                case R.id.ButtonLeftBracket:
                    setEditText('(');
                    break;
                case R.id.ButtonRightBracket:
                    setEditText(')');
                    break;
                case R.id.ButtonC:
                    flag = 0;

                    ((EditText) findViewById(R.id.EditTest1)).setText("");
                    break;
                case R.id.ButtonDel:
                    delete();
                    break;
                case R.id.ButtonRoot:
                    setEditText('^');
                    break;
                case R.id.ButtonSin:
                    setEditText("Sin");
                    break;
                case R.id.ButtonCos:
                    setEditText("Cos");
                    break;
                case R.id.ButtonTan:
                    setEditText("Tan");
                    break;
                case R.id.ButtonResult:
                    final EditText editText = (EditText) findViewById(R.id.EditTest1);

                    String format = editText.getText().toString();

                    if (format.equals("")) break;

                    if (flag == 3) break;
                    if (flag == 4) break;

                    if (ExpressionPosfix.isMatched(format))
                        editText.setText(ExpressionPosfix.Value(ExpressionPosfix.toPostfix(format)) + "");
                    else
                        editText.setText("括号不匹配");

                    flag = 1;

                    break;
                default:
                    break;
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button1 = (Button) findViewById(R.id.ButtonOne);
        button1.setOnClickListener(new PressNumber());

        final Button button2 = (Button) findViewById(R.id.ButtonTwo);
        button2.setOnClickListener(new PressNumber());

        final Button button3 = (Button) findViewById(R.id.ButtonThree);
        button3.setOnClickListener(new PressNumber());

        final Button button4 = (Button) findViewById(R.id.ButtonFour);
        button4.setOnClickListener(new PressNumber());

        final Button button5 = (Button) findViewById(R.id.ButtonFive);
        button5.setOnClickListener(new PressNumber());

        final Button button6 = (Button) findViewById(R.id.ButtonSix);
        button6.setOnClickListener(new PressNumber());

        final Button button7 = (Button) findViewById(R.id.ButtonSeven);
        button7.setOnClickListener(new PressNumber());

        final Button button8 = (Button) findViewById(R.id.ButtonEight);
        button8.setOnClickListener(new PressNumber());

        final Button button9 = (Button) findViewById(R.id.ButtonNine);
        button9.setOnClickListener(new PressNumber());

        final Button button0 = (Button) findViewById(R.id.ButtonZero);
        button0.setOnClickListener(new PressNumber());

        final Button buttonAdd = (Button) findViewById(R.id.ButtonPlus);
        buttonAdd.setOnClickListener(new PressNumber());

        final Button buttonMinus = (Button) findViewById(R.id.ButtonMinus);
        buttonMinus.setOnClickListener(new PressNumber());

        final Button buttonMul = (Button) findViewById(R.id.ButtonMultiply);
        buttonMul.setOnClickListener(new PressNumber());

        final Button buttonDiv = (Button) findViewById(R.id.ButtonDiv);
        buttonDiv.setOnClickListener(new PressNumber());

        final Button buttonPoint = (Button) findViewById(R.id.ButtonPoint);
        buttonPoint.setOnClickListener(new PressNumber());

        final Button buttonLeftBracket = (Button) findViewById(R.id.ButtonLeftBracket);
        buttonLeftBracket.setOnClickListener(new PressNumber());

        final Button buttonRightBracket = (Button) findViewById(R.id.ButtonRightBracket);
        buttonRightBracket.setOnClickListener(new PressNumber());

        final Button buttonDel = (Button) findViewById(R.id.ButtonDel);
        buttonDel.setOnClickListener(new PressNumber());

        final Button buttonC = (Button) findViewById(R.id.ButtonC);
        buttonC.setOnClickListener(new PressNumber());

        final Button buttonEqual = (Button) findViewById(R.id.ButtonResult);
        buttonEqual.setOnClickListener(new PressNumber());

        final Button buttonRoot = (Button) findViewById(R.id.ButtonRoot);
        buttonRoot.setOnClickListener(new PressNumber());

        final Button buttonSin = (Button) findViewById(R.id.ButtonSin);
        buttonSin.setOnClickListener(new PressNumber());

        final Button buttonCos = (Button) findViewById(R.id.ButtonCos);
        buttonCos.setOnClickListener(new PressNumber());

        final Button buttonTan = (Button) findViewById(R.id.ButtonTan);
        buttonTan.setOnClickListener(new PressNumber());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.toTransitions:
                Intent intentT = new Intent(MainActivity.this, transitions.class);

                startActivity(intentT);

                Toast.makeText(this, "您已经切换到进制转换页面", Toast.LENGTH_SHORT).show();

                break;

            case R.id.Help:
                Intent intentH = new Intent(MainActivity.this, HelpPage.class);

                startActivity(intentH);

                break;

            case R.id.Exit:
                finish();

                break;
        }

        return true;
    }

    public void setEditText(char number) {
        final EditText editText = (EditText) findViewById(R.id.EditTest1);

        if (flag == 1) {
            editText.setText("");

            flag = 0;
        }

        if (number == '-') {
            if (flag == 0 && minusCount == 1) return;//在算式的开头最多添加一个负号

            if (minusCount == 2 || flag == 3 && minusCount == 1) return;//在算式中最多只能添加两个负号

            if (minusCount == 1) flag = 3;//如果是在开头，当做符号；否则当做减号

            minusCount++;
        }
        /*
         符号不能和符号相连
         */
        else if ((flag == 0 || flag == 3) && (number == '+' || number == '/' ||
                number == '*' || number == '^' || number == '.'))
            return;
        else if (number >= '0' && number <= '9' || number == ')') {
            flag = 2;

            minusCount = 0;
        } else {
            flag = 3;

            minusCount = 0;
        }

        String format = editText.getText().toString();

        format += number;

        editText.setText(format);
    }

    public void setEditText(String number) {
        final EditText editText = (EditText) findViewById(R.id.EditTest1);

        if (flag == 1) {
            editText.setText("");

            flag = 0;
        }

        if (flag == 4) return;

        if (number.equals("Sin") || number.equals("Cos") || number.equals("Tan")) flag = 4;

        String format = editText.getText().toString();

        format += number;

        editText.setText(format);
    }

    public void delete() {
        final EditText editText = (EditText) findViewById(R.id.EditTest1);

        String format = editText.getText().toString();

        if (format.length() == 0) return;

        if (format.length() == 1) {
            editText.setText("");

            flag = 0;

            return;
        }

        format = format.substring(0, format.length() - 1);

        char ch = format.charAt(format.length() - 1);

        if (ch >= '0' && ch <= '9') flag = 2;
        else
            flag = 3;

        editText.setText(format);
    }
}
