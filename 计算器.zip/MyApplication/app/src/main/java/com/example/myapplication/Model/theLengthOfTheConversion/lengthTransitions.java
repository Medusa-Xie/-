package com.example.myapplication.Model.theLengthOfTheConversion;

public class lengthTransitions {
    public static double dmToM(double dm) {
        return (dm / 10);
    }

    public static double cmToM(double cm) {
        return (cm / 100);
    }

    public static double mmToM(double mm) {
        return (mm / 1000);
    }

    public static double umToM(double um) {
        return (um / 1000000);
    }

    public static double nmToM(double nm) {
        return (nm / 1000000000);
    }

    public static double mToDm(double m) {
        return (m * 10);
    }

    public static double mToCm(double m) {
        return (m * 100);
    }

    public static double mToMm(double m) {
        return (m * 1000);
    }

    public static double mToUm(double m) {
        return (m * 1000000);
    }

    public static String mToNm(double m) {
        return (m * 1000000000) + "";
    }
}
