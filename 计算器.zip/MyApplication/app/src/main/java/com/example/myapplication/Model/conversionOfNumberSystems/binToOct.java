package com.example.myapplication.Model.conversionOfNumberSystems;

/**
 * 二进制转换为八进制
 */
public class binToOct {
    public static String trans(String binNumber) {
        int location = separate(binNumber);
        String binDecimal = "";
        String result = "";

        String binInteger = binNumber.substring(0, location);

        if (location != binNumber.length()) binDecimal = binNumber.substring(location + 1);

        result += binIntergerToOct(binInteger);

        if (binDecimal.length() == 0) return result;

        return result + "." + binDecimalToOct(binDecimal);
    }

    /**
     * 将传入的二进制字符串分离。
     * 如果带有小数点，则分离点在小数点前；如果没有小数点，则分离点在最后一位
     * @param binNumber 目标二进制字符串
     * @return 分离点
     */
    public static int separate(String binNumber) {
        int i;

        for (i = 0; i < binNumber.length(); i++) {
            if (binNumber.charAt(i) == '.') return i;
        }

        return i;
    }

    public static String binDecimalToOct(String decimal) {
        String result = "";
        String nowResult = "";//每三位数字转换为八进制的结果

        for (int i = 1; i <= decimal.length(); i++) {
            char c = decimal.charAt(i - 1);

            nowResult += c;

            if (i % 3 == 0) {
                result += toOct(nowResult);

                nowResult = "";
            }
        }

        if (decimal.length() % 3 == 0) return result;

        nowResult += "00";

        result += toOct(nowResult);

        return result;
    }

    public static String binIntergerToOct(String integer) {
        String result = "";
        String nowResult = "";//每三位数字转换为八进制的结果
        int j = 0;

        for (int i = integer.length() - 1; i >= 0; i--) {
            char c = integer.charAt(i);

            nowResult = c + nowResult;

            j++;

            if (j % 3 == 0) {
                result = toOct(nowResult) + result;

                nowResult = "";
            }
        }

        if (integer.length() % 3 == 0) return result;

        if (nowResult.length() == 1) nowResult = "00" + nowResult;
        else
            nowResult = "0" + nowResult;

        result = toOct(nowResult) + result;

        return result;
    }

    public static String toOct(String binNumber) {
        return ((binNumber.charAt(0) - '0') * 4 +
                (binNumber.charAt(1) - '0') * 2 + (binNumber.charAt(2) - '0') * 1) + "";
    }

    public static void main(String[] args) {
        System.out.println(trans("11101.10"));
    }
}
