package com.example.myapplication.Model;

public class checkDecimal {
    /**
     * 检查十进制数是否合法
     * @param decimal 目标十进制数
     * @return 是否合法？
     */
    public static boolean isLegal(String decimal) {
        for (int i = 0; i < decimal.length(); i++) {
            char ch = decimal.charAt(i);

            if (ch >= '0' && ch <= '9' || ch == '.') continue;
            else
                return false;
        }

        return true;
    }
}
