package com.example.myapplication.Model.volumeTransformation;

public class volumeTransitions {
    public static double cm3ToM3(double cm3) {
        return cm3 / 1000000;
    }

    public static double dm3ToM3(double dm3) {
        return dm3 / 1000;
    }

    public static double m3ToDm3(double m3) {
        return m3 * 1000;
    }

    public static double m3ToCm3(double m3) {
        return m3 * 1000000;
    }
}
