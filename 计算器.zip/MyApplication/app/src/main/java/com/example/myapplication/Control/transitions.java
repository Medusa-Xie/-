package com.example.myapplication.Control;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Model.conversionOfNumberSystems.*;
import com.example.myapplication.Model.theLengthOfTheConversion.lengthTransitions;
import com.example.myapplication.Model.volumeTransformation.*;
import com.example.myapplication.Model.*;
import com.example.myapplication.R;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class transitions extends AppCompatActivity {

    private class ButtonListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.ButtonFrom:
                    final Button buttonFrom = (Button) findViewById(R.id.ButtonFrom);

                    setButton(buttonFrom);

                    break;

                case R.id.ButtonTo:
                    final Button buttonTo = (Button) findViewById(R.id.ButtonTo);

                    setButton(buttonTo);

                    break;

                case R.id.LenFrom:
                    final Button lenFrom = (Button) findViewById(R.id.LenFrom);

                    setButtonLen(lenFrom);

                    break;

                case R.id.LenTo:
                    final Button lenTo = (Button) findViewById(R.id.LenTo);

                    setButtonLen(lenTo);

                    break;

                case R.id.volFrom:
                    final Button volFrom = (Button) findViewById(R.id.volFrom);

                    setButttonVol(volFrom);

                    break;

                case R.id.VolTo:
                    final Button volTo = (Button) findViewById(R.id.VolTo);


                    setButttonVol(volTo);

                    break;
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transitions);

        final Button buttonFrom = (Button) findViewById(R.id.ButtonFrom);
        buttonFrom.setOnClickListener(new ButtonListener());

        final Button buttonTo = (Button) findViewById(R.id.ButtonTo);
        buttonTo.setOnClickListener(new ButtonListener());

        final Button transNum = (Button) findViewById(R.id.trans);
        transNum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText editText = (EditText) findViewById(R.id.transEditText);
                final EditText editTextResult = (EditText) findViewById(R.id.result);
                final Button buttonFrom = (Button) findViewById(R.id.ButtonFrom);
                final Button buttonTo = (Button) findViewById(R.id.ButtonTo);

                String from = buttonFrom.getText().toString();
                String to = buttonTo.getText().toString();

                String targetNumber = editText.getText().toString();//需要转换的数字

                if (targetNumber.isEmpty()) return;

                switch (from) {
                    case "二进制":
                        if (!checkBinary.isLegal(targetNumber)) {
                            editTextResult.setText("二进制数不合法");

                            return;
                        }

                        break;
                    case "八进制":
                        if (!checkOctonary.isLegal(targetNumber)) {
                            editTextResult.setText("八进制数不合法");

                            return;
                        }

                        targetNumber = OctToBin.trans(targetNumber);
                        break;
                    case "十进制":
                        if (!checkDecimal.isLegal(targetNumber)) {
                            editTextResult.setText("十进制数不合法");

                            return;
                        }

                        targetNumber = decToBin.trans(Double.parseDouble(targetNumber));
                        break;
                    case "十六进制":
                        if (!checkHexadecimal.isLegal(targetNumber)) {
                            editTextResult.setText("十六进制数不合法");

                            return;
                        }

                        targetNumber = hexToBin.trans(targetNumber);
                        break;
                }

                switch (to) {
                    case "二进制":
                        editTextResult.setText(targetNumber);
                        break;
                    case "八进制":
                        editTextResult.setText(binToOct.trans(targetNumber));
                        break;
                    case "十进制":
                        editTextResult.setText(binToDec.trans(targetNumber));
                        break;
                    case "十六进制":
                        editTextResult.setText(binToHex.trans(targetNumber));
                        break;
                }
            }
        });

        final Button lenFrom = (Button) findViewById(R.id.LenFrom);
        lenFrom.setOnClickListener(new ButtonListener());

        final Button lenTo = (Button) findViewById(R.id.LenTo);
        lenTo.setOnClickListener(new ButtonListener());

        final Button buttonLen = (Button) findViewById(R.id.transL);
        buttonLen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText editTextL = (EditText) findViewById(R.id.transEditTextL);
                final EditText editTextResultL = (EditText) findViewById(R.id.resultL);
                final Button lenFrom = (Button) findViewById(R.id.LenFrom);
                final Button lenTo = (Button) findViewById(R.id.LenTo);

                String from = lenFrom.getText().toString();
                String to = lenTo.getText().toString();

                double targetNumber = Double.parseDouble(editTextL.getText().toString());//需要转换的数字

                if ((targetNumber + "").isEmpty()) return;

                if (from.equals(to)) {
                    editTextResultL.setText(editTextL.getText().toString());

                    return;
                }

                switch (from) {
                    case "米":
                        break;
                    case "分米":
                        targetNumber = lengthTransitions.dmToM(targetNumber);
                        break;
                    case "厘米":
                        targetNumber = lengthTransitions.cmToM(targetNumber);
                        break;
                    case "毫米":
                        targetNumber = lengthTransitions.mmToM(targetNumber);
                        break;
                    case "微米":
                        targetNumber = lengthTransitions.umToM(targetNumber);
                        break;
                    case "纳米":
                        targetNumber = lengthTransitions.nmToM(targetNumber);
                        break;
                }

                switch (to) {
                    case "米":
                        editTextResultL.setText(targetNumber + "");
                        break;
                    case "分米":
                        editTextResultL.setText(lengthTransitions.mToDm(targetNumber) + "");
                        break;
                    case "厘米":
                        editTextResultL.setText(lengthTransitions.mToCm(targetNumber) + "");
                        break;
                    case "毫米":
                        editTextResultL.setText(lengthTransitions.mToMm(targetNumber) + "");
                        break;
                    case "微米":
                        editTextResultL.setText(lengthTransitions.mToUm(targetNumber) + "");
                        break;
                    case "纳米":
                        editTextResultL.setText(lengthTransitions.mToNm(targetNumber) + "");
                        break;
                }
            }
        });

        final Button volFrom = (Button) findViewById(R.id.volFrom);
        volFrom.setOnClickListener(new ButtonListener());

        final Button volTo = (Button) findViewById(R.id.VolTo);
        volTo.setOnClickListener(new ButtonListener());

        final Button transV = (Button) findViewById(R.id.transV);
        transV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText transEditTextV = (EditText) findViewById(R.id.transEditTextV);
                final EditText resultV = (EditText) findViewById(R.id.resultV);
                final Button volFrom = (Button) findViewById(R.id.volFrom);
                final Button volTo = (Button) findViewById(R.id.VolTo);

                String from = volFrom.getText().toString();
                String to = volTo.getText().toString();

                double targetNumber = Double.parseDouble(transEditTextV.getText().toString());

                if ((targetNumber + "").isEmpty()) return;

                switch (from) {
                    case "cm3/mL":
                        targetNumber = volumeTransitions.cm3ToM3(targetNumber);
                        break;
                    case "dm3/L":
                        targetNumber = volumeTransitions.dm3ToM3(targetNumber);
                        break;
                    case "m3":
                        break;
                }

                switch (to) {
                    case "cm3/mL":
                        targetNumber = volumeTransitions.m3ToCm3(targetNumber);

                        resultV.setText(targetNumber + "");
                        break;
                    case "dm3/L":
                        targetNumber = volumeTransitions.m3ToDm3(targetNumber);
                        resultV.setText(targetNumber + "");
                        break;
                    case "m3":
                        resultV.setText(targetNumber + "");
                        break;
                }
            }
        });
    }

    private void setButton(final Button button) {
        new AlertDialog.Builder(transitions.this)
                .setTitle("选择进制")
                .setIcon(R.mipmap.timg2)
                .setSingleChoiceItems(new String[]{"二进制", "八进制", "十进制", "十六进制"}, 0,
                        new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i) {
                            case 0:
                                button.setText("二进制");
                                break;
                            case 1:
                                button.setText("八进制");
                                break;
                            case 2:
                                button.setText("十进制");
                                break;
                            case 3:
                                button.setText("十六进制");
                                break;
                        }
                    }
                })
                .setPositiveButton("确定", null)
                .show();
    }

    private void setButtonLen(final Button button) {
        new AlertDialog.Builder(transitions.this)
                .setTitle("选择长度单位")
                .setIcon(R.mipmap.timg2)
                .setSingleChoiceItems(new String[]{"米", "分米", "厘米", "毫米", "微米", "纳米"}, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i) {
                            case 0:
                                button.setText("米");
                                break;
                            case 1:
                                button.setText("分米");
                                break;
                            case 2:
                                button.setText("厘米");
                                break;
                            case 3:
                                button.setText("毫米");
                                break;
                            case 4:
                                button.setText("微米");
                                break;
                            case 5:
                                button.setText("纳米");
                                break;
                        }
                    }
                })
                .setPositiveButton("确定", null)
                .show();
    }

    private void setButttonVol(final Button buttton) {
        new AlertDialog.Builder(transitions.this)
                .setTitle("请选择进制")
                .setIcon(R.mipmap.timg2)
                .setSingleChoiceItems(new String[]{"cm3/mL", "dm3/L", "m3"}, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i) {
                            case 0:
                                buttton.setText("cm3/mL");

                                break;
                            case 1:
                                buttton.setText("dm3/L");

                                break;

                            case 2:
                                buttton.setText("m3");

                                break;
                        }
                    }
                })
                .setPositiveButton("确定", null)
                .show();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.transitions_main, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.transitionsToCalculator:
                Intent intent = new Intent(transitions.this, MainActivity.class);

                startActivity(intent);

                Toast.makeText(this, "您已经切换到计算器页面", Toast.LENGTH_SHORT).show();

                break;

            case R.id.Exit:
                finish();

                break;
        }

        return true;
    }
}

