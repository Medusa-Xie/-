package com.example.myapplication.Model;

public class checkBinary {
    /**
     * 检查二进制数是否合法
     * @param binary 目标二进制数
     * @return 是否合法？
     */
    public static boolean isLegal(String binary) {
        for (int i = 0; i < binary.length(); i++) {
            char ch = binary.charAt(i);

            if (ch == '1' || ch == '0' || ch == '.') continue;
            else
                return false;
        }

        return true;
    }
}
