package com.example.myapplication.Model;

public class checkOctonary {
    /**
     * 检查八进制数是否合法
     * @param octonary 目标八进制数
     * @return 是否合法
     */
    public static boolean isLegal(String octonary) {
        for (int i = 0; i < octonary.length(); i++) {
            char ch = octonary.charAt(i);

            if (ch >= '0' && ch <= '7') continue;
            else
                return false;
        }

        return true;
    }
}
