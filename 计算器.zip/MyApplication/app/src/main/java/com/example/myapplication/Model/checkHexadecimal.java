package com.example.myapplication.Model;

public class checkHexadecimal {
    /**
     * 检查十六进制数是否合法
     * @param hexadecimal 目标十六进制数
     * @return 是否合法？
     */
    public static boolean isLegal(String hexadecimal) {
        for (int i = 0; i < hexadecimal.length(); i++) {
            char ch = hexadecimal.charAt(i);

            if (ch >= '0' && ch <= '9' || ch >= 'A' && ch <= 'F' || ch >= 'a' && ch <= 'f') continue;
            else
                return false;
        }

        return true;
    }
}
