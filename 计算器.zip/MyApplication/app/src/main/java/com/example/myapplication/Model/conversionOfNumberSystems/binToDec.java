package com.example.myapplication.Model.conversionOfNumberSystems;

/**
 * 二进制转换为十进制
 */
public class binToDec {
    public static String trans(String binNumber) {
        int location = separate(binNumber);
        String binDecimal = "";//小数部分
        double result = 0;

        String binInteger = binNumber.substring(0, location);//整数部分

        if (location != binNumber.length()) binDecimal = binNumber.substring(location + 1);

        result += binIntegerToDec(binInteger);

        if (binDecimal.length() == 0) return result + "";

        return result + binDecimalToDec(binDecimal) + "";
    }

    public static int separate(String binNumber) {
        int i;

        for (i = 0; i < binNumber.length(); i++) {
            if (binNumber.charAt(i) == '.') return i;
        }

        return i;
    }

    public static double binDecimalToDec(String decimal) {
        double result = 0;

        for (int i = 1; i <= decimal.length(); i++)
            result += (decimal.charAt(i - 1) - '0') * Math.pow(2, 0 - i);

        return result;
    }

    public static int binIntegerToDec(String integer) {
        int result = 0;

        for (int i = integer.length() - 1; i >= 0; i--)
            result += (integer.charAt(i) - '0') * Math.pow(2, integer.length() - 1 - i);

        return result;
    }

    public static void main(String[] args) {
        System.out.println(trans("1.11001"));
    }
}
