package com.example.myapplication.Model;

/**
 * 顺序栈
 * @param <item> 栈内元素类型
 */
public class SeqStack<item> {
    private Object[] array;//Object数组
    private int N = 0;//记录栈内元素个数

    public SeqStack(int length) {
        array = (item[]) new Object[length];//初始化为长度为length的item类型数组
    }

    public SeqStack() {
        this(64);//初始化为长度为64的item类型数组
    }

    public boolean isEmpty() {
        return N == 0;
    }

    public void push(item x) {
        if (N == array.length)
            resize(array.length * 2);
        //动态调整数组的大小

        array[N++] = x;
    }

    public item pop() {
        if (isEmpty())
            return null;

        item old = (item) array[--N];

        array[N] = null;//避免对象游离

        if (N > 0 && N == array.length / 4)
            resize(array.length / 2);
        //动态调整数组的大小

        return old;
    }

    public item peek() {
        if (isEmpty())
            return null;

        return (item) array[N - 1];
    }

    public int size() {
        return N;
    }

    public void resize(int length) {
        Object[] array = (item[]) new Object[length];

        for (int i = 0; i < length; i++)
            array[i] = array[i];

        this.array = array;//将array指向arr，即用arr代替array
    }
}
