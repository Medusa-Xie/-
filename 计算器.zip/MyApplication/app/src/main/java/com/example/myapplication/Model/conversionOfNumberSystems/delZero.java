package com.example.myapplication.Model.conversionOfNumberSystems;

public class delZero {
    public static String del(String string) {
        int j = 0;

        for (int i = 0; i < string.length(); i++) {
            if (string.charAt(i) == '0') j++;
            else
                break;
        }

        return string.substring(j, string.length());
    }

    public static void main(String[] args) {
        System.out.println(del("00111"));
    }
}
