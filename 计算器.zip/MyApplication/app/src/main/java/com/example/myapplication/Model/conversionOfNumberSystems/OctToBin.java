package com.example.myapplication.Model.conversionOfNumberSystems;

/**
 * 将八进制转换为二进制
 */
public class OctToBin {
    public static String trans(String OctNumber) {
        int location = separate(OctNumber);

        String octInteger = OctNumber.substring(0, location);
        String octDecimal = "";

        if (location < OctNumber.length()) {
            octDecimal = OctNumber.substring(location + 1);

            return octToBin(octInteger) + "." + octToBin(octDecimal);
        }

        return octToBin(octInteger);
    }

    public static int separate(String binNumber) {
        int i;

        for (i = 0; i < binNumber.length(); i++) {
            if (binNumber.charAt(i) == '.') return i;
        }

        return i;
    }

    public static String octToBin(String decimal) {
        String result = "";

        for (int i = 0; i < decimal.length(); i++) {
            char c = decimal.charAt(i);

            switch (c) {
                case '0':
                    result += "000";
                    break;
                case '1':
                    result += "001";
                    break;
                case '2':
                    result += "010";
                    break;
                case '3':
                    result += "011";
                    break;
                case '4':
                    result += "100";
                    break;
                case '5':
                    result += "101";
                    break;
                case '6':
                    result += "110";
                    break;
                case '7':
                    result += "111";
                    break;
            }
        }

        return delZero.del(result);
    }

    public static void main(String[] rags) {
        System.out.println(trans("171111"));
    }
}
